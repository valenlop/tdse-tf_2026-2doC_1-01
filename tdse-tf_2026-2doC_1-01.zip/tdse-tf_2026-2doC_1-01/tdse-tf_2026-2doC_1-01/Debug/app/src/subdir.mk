################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../app/src/app.c \
../app/src/app_it.c \
../app/src/ble_uart.c \
../app/src/eeprom.c \
../app/src/lcd.c \
../app/src/logger.c \
../app/src/systick.c \
../app/src/task_actuator.c \
../app/src/task_actuator_interface.c \
../app/src/task_bluetooth.c \
../app/src/task_bluetooth_interface.c \
../app/src/task_button.c \
../app/src/task_display.c \
../app/src/task_display_interface.c \
../app/src/task_sensor.c \
../app/src/task_sensor_interface.c \
../app/src/task_signaling.c \
../app/src/task_signaling_interface.c \
../app/src/task_system.c \
../app/src/task_system_interface.c \
../app/src/task_ui.c \
../app/src/task_ui_interface.c 

OBJS += \
./app/src/app.o \
./app/src/app_it.o \
./app/src/ble_uart.o \
./app/src/eeprom.o \
./app/src/lcd.o \
./app/src/logger.o \
./app/src/systick.o \
./app/src/task_actuator.o \
./app/src/task_actuator_interface.o \
./app/src/task_bluetooth.o \
./app/src/task_bluetooth_interface.o \
./app/src/task_button.o \
./app/src/task_display.o \
./app/src/task_display_interface.o \
./app/src/task_sensor.o \
./app/src/task_sensor_interface.o \
./app/src/task_signaling.o \
./app/src/task_signaling_interface.o \
./app/src/task_system.o \
./app/src/task_system_interface.o \
./app/src/task_ui.o \
./app/src/task_ui_interface.o 

C_DEPS += \
./app/src/app.d \
./app/src/app_it.d \
./app/src/ble_uart.d \
./app/src/eeprom.d \
./app/src/lcd.d \
./app/src/logger.d \
./app/src/systick.d \
./app/src/task_actuator.d \
./app/src/task_actuator_interface.d \
./app/src/task_bluetooth.d \
./app/src/task_bluetooth_interface.d \
./app/src/task_button.d \
./app/src/task_display.d \
./app/src/task_display_interface.d \
./app/src/task_sensor.d \
./app/src/task_sensor_interface.d \
./app/src/task_signaling.d \
./app/src/task_signaling_interface.d \
./app/src/task_system.d \
./app/src/task_system_interface.d \
./app/src/task_ui.d \
./app/src/task_ui_interface.d 


# Each subdirectory must supply rules for building sources it contributes
app/src/%.o app/src/%.su app/src/%.cyclo: ../app/src/%.c app/src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Core/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -I../app/inc -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-app-2f-src

clean-app-2f-src:
	-$(RM) ./app/src/app.cyclo ./app/src/app.d ./app/src/app.o ./app/src/app.su ./app/src/app_it.cyclo ./app/src/app_it.d ./app/src/app_it.o ./app/src/app_it.su ./app/src/ble_uart.cyclo ./app/src/ble_uart.d ./app/src/ble_uart.o ./app/src/ble_uart.su ./app/src/eeprom.cyclo ./app/src/eeprom.d ./app/src/eeprom.o ./app/src/eeprom.su ./app/src/lcd.cyclo ./app/src/lcd.d ./app/src/lcd.o ./app/src/lcd.su ./app/src/logger.cyclo ./app/src/logger.d ./app/src/logger.o ./app/src/logger.su ./app/src/systick.cyclo ./app/src/systick.d ./app/src/systick.o ./app/src/systick.su ./app/src/task_actuator.cyclo ./app/src/task_actuator.d ./app/src/task_actuator.o ./app/src/task_actuator.su ./app/src/task_actuator_interface.cyclo ./app/src/task_actuator_interface.d ./app/src/task_actuator_interface.o ./app/src/task_actuator_interface.su ./app/src/task_bluetooth.cyclo ./app/src/task_bluetooth.d ./app/src/task_bluetooth.o ./app/src/task_bluetooth.su ./app/src/task_bluetooth_interface.cyclo ./app/src/task_bluetooth_interface.d ./app/src/task_bluetooth_interface.o ./app/src/task_bluetooth_interface.su ./app/src/task_button.cyclo ./app/src/task_button.d ./app/src/task_button.o ./app/src/task_button.su ./app/src/task_display.cyclo ./app/src/task_display.d ./app/src/task_display.o ./app/src/task_display.su ./app/src/task_display_interface.cyclo ./app/src/task_display_interface.d ./app/src/task_display_interface.o ./app/src/task_display_interface.su ./app/src/task_sensor.cyclo ./app/src/task_sensor.d ./app/src/task_sensor.o ./app/src/task_sensor.su ./app/src/task_sensor_interface.cyclo ./app/src/task_sensor_interface.d ./app/src/task_sensor_interface.o ./app/src/task_sensor_interface.su ./app/src/task_signaling.cyclo ./app/src/task_signaling.d ./app/src/task_signaling.o ./app/src/task_signaling.su ./app/src/task_signaling_interface.cyclo ./app/src/task_signaling_interface.d ./app/src/task_signaling_interface.o ./app/src/task_signaling_interface.su ./app/src/task_system.cyclo ./app/src/task_system.d ./app/src/task_system.o ./app/src/task_system.su ./app/src/task_system_interface.cyclo ./app/src/task_system_interface.d ./app/src/task_system_interface.o ./app/src/task_system_interface.su ./app/src/task_ui.cyclo ./app/src/task_ui.d ./app/src/task_ui.o ./app/src/task_ui.su ./app/src/task_ui_interface.cyclo ./app/src/task_ui_interface.d ./app/src/task_ui_interface.o ./app/src/task_ui_interface.su

.PHONY: clean-app-2f-src

