/*
 * Copyright (c) 2026 Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira
 *           (basado en el template TdSE de Juan Manuel Cruz <jcruz@fi.uba.ar>)
 */

/********************** inclusions *******************************************/
/* Project includes */
#include "main.h"

/* Demo includes */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes */
#include "board.h"
#include "app.h"
#include "eeprom.h"
#include "task_sensor_interface.h"
#include "task_actuator_attribute.h"
#include "task_actuator_interface.h"
#include "task_ui_interface.h"
#include "task_display_interface.h"
#include "task_signaling_interface.h"
#include "task_bluetooth_interface.h"
#include "task_system_attribute.h"
#include "task_system_interface.h"

/********************** macros and definitions *******************************/
#define DEL_SYS_MIN			0ul

/* Valores por defecto del statechart task_system */
#define T_MEDIDA_INI		(20.0f)
#define T_SET_INI			(100.0f)		/* setp oint: por debajo de T_SET - dT calienta */
#define D_T_INI				(1.0f)		/* histeresis */
#define T_MAX_INI			(150.0f)		/* por encima salta ALARMA */
#define LDR_VAL_INI			(100ul)
#define UMBRAL_LUZ_INI		(500ul)		/* LDR: por encima salta ALARMA (tapa) */

/********************** internal data declaration ****************************/
task_system_dta_t task_system_dta;

/********************** internal functions declaration ***********************/
void task_system_statechart(void);

static void task_system_enter(task_system_st_t state);
static void task_system_raise_mode_changed(void);
static bool task_system_alarm_condition(void);
static void task_system_set_param(float valor_nuevo);

/* Operaciones del statechart implementadas en C */
static bool eeprom_save(system_param_t p, float v);
static system_alarm_cause_t alarm_cause(void);

/********************** internal data definition *****************************/
const char *p_task_system 		= "Task System (System Statechart)";
const char *p_task_system_ 		= "Non-Blocking Code";
const char *p_task_system__ 	= "(Update by Time Code, period = 1mS)";

static const char *p_mode_name[] = {"INIT", "NORMAL", "HEATING", "SET_UP", "ALARMA"};

/********************** external data declaration ****************************/

/********************** external functions definition ***********************/
void task_system_init(void *parameters)
{
	task_system_dta_t *p_task_system_dta;
	float t_set, t_max;

	/* Print out: Task Initialized */
	LOGGER_INFO(" ");
	LOGGER_INFO("  %s is running - Tick [mS] = %lu", GET_NAME(task_system_init), HAL_GetTick());
	LOGGER_INFO("   %s is a %s", GET_NAME(task_system), p_task_system);
	LOGGER_INFO("   %s is a %s", GET_NAME(task_system), p_task_system_);
	LOGGER_INFO("   %s is a %s", GET_NAME(task_system), p_task_system__);

	init_event_task_system();

	/* Update Task System Data Pointer */
	p_task_system_dta = &task_system_dta;

	/* Init variables of the statechart */
	p_task_system_dta->tick         = DEL_SYS_MIN;
	p_task_system_dta->event        = EV_SYS_INIT_DONE;
	p_task_system_dta->value        = 0.0f;
	p_task_system_dta->flag         = false;
	p_task_system_dta->t_medida     = T_MEDIDA_INI;
	p_task_system_dta->t_set        = T_SET_INI;
	p_task_system_dta->d_t          = D_T_INI;
	p_task_system_dta->t_max        = T_MAX_INI;
	p_task_system_dta->ldr_val      = LDR_VAL_INI;
	p_task_system_dta->umbral_luz   = UMBRAL_LUZ_INI;
	p_task_system_dta->causa_alarma = CAUSA_NONE;

	/* UC-01 precondition: recover setpoints from EEPROM */
	if (true == eeprom_read_config(&t_set, &t_max))
	{
		p_task_system_dta->t_set = t_set;
		p_task_system_dta->t_max = t_max;
		LOGGER_INFO("   EEPROM ok: T_set = %d dC, T_max = %d dC", (int)(t_set * 10.0f), (int)(t_max * 10.0f));
	}
	else
	{
		/* Empty / corrupted / absent EEPROM: keep defaults and try to store them */
		(void)eeprom_write_config(p_task_system_dta->t_set, p_task_system_dta->t_max);
		LOGGER_INFO("   EEPROM sin datos validos: se usan valores por defecto");
	}

	/* Heartbeat LED: system alive */
	put_event_task_actuator(EV_ACT_LED_BLINK, ID_LED_HB);

	/* Initial transition: Entry -> ST_INIT */
	task_system_enter(ST_SYS_INIT);

	LOGGER_INFO(" ");
	LOGGER_INFO("   %s = %lu   %s = %lu   %s = %s",
				GET_NAME(state), (uint32_t)p_task_system_dta->state,
				GET_NAME(event), (uint32_t)p_task_system_dta->event,
				GET_NAME(b_event), (p_task_system_dta->flag ? "true" : "false"));
}

void task_system_update(void *parameters)
{
	/* Run Task Statechart */
	task_system_statechart();
}

void task_system_statechart(void)
{
	task_system_dta_t *p_task_system_dta;

	/* Update Task System Data Pointer */
	p_task_system_dta = &task_system_dta;

	if (true == any_event_task_system())
	{
		p_task_system_dta->flag = true;
		p_task_system_dta->event = get_event_task_system(&p_task_system_dta->value);
	}

	/* EV_SENSE_TICK carries the new measurement (T_medida, LDR_val) */
	if ((true == p_task_system_dta->flag) && (EV_SYS_SENSE_TICK == p_task_system_dta->event))
	{
		p_task_system_dta->t_medida = get_temperature_task_sensor();
		p_task_system_dta->ldr_val  = get_ldr_task_sensor();
	}

	switch (p_task_system_dta->state)
	{
		case ST_SYS_INIT:

			/* EV_INIT_DONE */
			if ((true == p_task_system_dta->flag) && (EV_SYS_INIT_DONE == p_task_system_dta->event))
			{
				p_task_system_dta->flag = false;
				task_system_enter(ST_SYS_NORMAL);
			}

			break;

		case ST_SYS_NORMAL:

			/* EV_SENSE_TICK [T_medida > T_max || LDR_val > UMBRAL_LUZ] (safety first) */
			if ((true == p_task_system_dta->flag) && (EV_SYS_SENSE_TICK == p_task_system_dta->event)
				&& (true == task_system_alarm_condition()))
			{
				p_task_system_dta->flag = false;
				task_system_enter(ST_SYS_ALARMA);
			}
			/* EV_SENSE_TICK [T_medida < (T_set - dT)] */
			else if ((true == p_task_system_dta->flag) && (EV_SYS_SENSE_TICK == p_task_system_dta->event)
				&& (p_task_system_dta->t_medida < (p_task_system_dta->t_set - p_task_system_dta->d_t)))
			{
				p_task_system_dta->flag = false;
				task_system_enter(ST_SYS_HEATING);
			}
			/* EV_REQ_SETUP */
			else if ((true == p_task_system_dta->flag) && (EV_SYS_REQ_SETUP == p_task_system_dta->event))
			{
				p_task_system_dta->flag = false;
				task_system_enter(ST_SYS_SET_UP);
			}
			/* EV_REQ_SET_PARAM / T_set = valor_nuevo; eeprom_save(PAR_TSET, valor_nuevo) */
			else if ((true == p_task_system_dta->flag) && (EV_SYS_REQ_SET_PARAM == p_task_system_dta->event))
			{
				p_task_system_dta->flag = false;
				task_system_set_param(p_task_system_dta->value);
			}

			break;

		case ST_SYS_HEATING:

			/* EV_SENSE_TICK [T_medida > T_max || LDR_val > UMBRAL_LUZ] (safety first) */
			if ((true == p_task_system_dta->flag) && (EV_SYS_SENSE_TICK == p_task_system_dta->event)
				&& (true == task_system_alarm_condition()))
			{
				p_task_system_dta->flag = false;
				task_system_enter(ST_SYS_ALARMA);
			}
			/* EV_SENSE_TICK [T_medida >= T_set] */
			else if ((true == p_task_system_dta->flag) && (EV_SYS_SENSE_TICK == p_task_system_dta->event)
				&& (p_task_system_dta->t_medida >= p_task_system_dta->t_set))
			{
				p_task_system_dta->flag = false;
				task_system_enter(ST_SYS_NORMAL);
			}
			/* EV_REQ_SETUP */
			else if ((true == p_task_system_dta->flag) && (EV_SYS_REQ_SETUP == p_task_system_dta->event))
			{
				p_task_system_dta->flag = false;
				task_system_enter(ST_SYS_SET_UP);
			}
			/* EV_REQ_SET_PARAM / T_set = valor_nuevo; eeprom_save(PAR_TSET, valor_nuevo) */
			else if ((true == p_task_system_dta->flag) && (EV_SYS_REQ_SET_PARAM == p_task_system_dta->event))
			{
				p_task_system_dta->flag = false;
				task_system_set_param(p_task_system_dta->value);
			}

			break;

		case ST_SYS_SET_UP:

			/* EV_SENSE_TICK [T_medida > T_max || LDR_val > UMBRAL_LUZ] */
			if ((true == p_task_system_dta->flag) && (EV_SYS_SENSE_TICK == p_task_system_dta->event)
				&& (true == task_system_alarm_condition()))
			{
				p_task_system_dta->flag = false;
				task_system_enter(ST_SYS_ALARMA);
			}
			/* EV_REQ_SAVE / T_set = valor_nuevo; eeprom_save(PAR_TSET, valor_nuevo)  (ver REVISION.md) */
			else if ((true == p_task_system_dta->flag) && (EV_SYS_REQ_SAVE == p_task_system_dta->event))
			{
				p_task_system_dta->flag = false;
				task_system_set_param(p_task_system_dta->value);
				task_system_enter(ST_SYS_NORMAL);
			}
			/* EV_REQ_NORMAL */
			else if ((true == p_task_system_dta->flag) && (EV_SYS_REQ_NORMAL == p_task_system_dta->event))
			{
				p_task_system_dta->flag = false;
				task_system_enter(ST_SYS_NORMAL);
			}
			/* EV_SETUP_TIMEOUT */
			else if ((true == p_task_system_dta->flag) && (EV_SYS_SETUP_TIMEOUT == p_task_system_dta->event))
			{
				p_task_system_dta->flag = false;
				task_system_enter(ST_SYS_NORMAL);
			}

			break;

		case ST_SYS_ALARMA:

					/* EV_SENSE_TICK [T_medida <= (T_max - dT) && LDR_val <= UMBRAL_LUZ] */
			if ((true == p_task_system_dta->flag) && (EV_SYS_SENSE_TICK == p_task_system_dta->event)
				&& (p_task_system_dta->t_medida <= (p_task_system_dta->t_max - p_task_system_dta->d_t))
				&& (p_task_system_dta->ldr_val <= p_task_system_dta->umbral_luz))
			{
				p_task_system_dta->flag = false;
				task_system_enter(ST_SYS_NORMAL);
					}

					break;

		default:

			p_task_system_dta->tick  = DEL_SYS_MIN;
			p_task_system_dta->flag  = false;
			task_system_enter(ST_SYS_INIT);

			break;
	}

	/* Events not handled in the current state are discarded */
	p_task_system_dta->flag = false;
}

/********************** internal functions definition ************************/
/* Transition: update state and run the entry actions of the target state */
static void task_system_enter(task_system_st_t state)
{
	task_system_dta_t *p_task_system_dta = &task_system_dta;

	p_task_system_dta->state = state;

	switch (state)
	{
		case ST_SYS_INIT:
			p_task_system_dta->relay = false;
			p_task_system_dta->modo_sistema = MODO_INIT;
			task_system_raise_mode_changed();
			break;

		case ST_SYS_NORMAL:
			p_task_system_dta->relay = false;
			p_task_system_dta->modo_sistema = MODO_NORMAL;
			task_system_raise_mode_changed();
			break;

		case ST_SYS_HEATING:
			p_task_system_dta->relay = true;
			p_task_system_dta->modo_sistema = MODO_HEATING;
			task_system_raise_mode_changed();
			break;

		case ST_SYS_SET_UP:
			p_task_system_dta->relay = false;
			p_task_system_dta->modo_sistema = MODO_SETUP;
			task_system_raise_mode_changed();
			break;

		case ST_SYS_ALARMA:
			p_task_system_dta->relay = false;
			p_task_system_dta->modo_sistema = MODO_ALARMA;
			p_task_system_dta->causa_alarma = alarm_cause();
			task_system_raise_mode_changed();
			/* alertaSistema -> statechart bluetooth (UC-03 paso 6) */
			put_event_task_bluetooth(EV_BLE_ALERTA_SISTEMA);
			break;

		default:
			break;
	}
}

/* raise EV_MODE_CHANGED : modo_sistema  ->  task_ui & task_signaling */
static void task_system_raise_mode_changed(void)
{
	system_mode_t modo = task_system_dta.modo_sistema;

	put_event_task_ui(EV_UI_MODE_CHANGED, (int32_t)modo);
	put_event_task_signaling(EV_SIG_MODE_CHANGED, (int32_t)modo);

	LOGGER_INFO("   task_system -> %s", p_mode_name[modo]);
}

/* [T_medida > T_max || LDR_val > UMBRAL_LUZ] */
static bool task_system_alarm_condition(void)
{
	return ((task_system_dta.t_medida > task_system_dta.t_max)
			|| (task_system_dta.ldr_val > task_system_dta.umbral_luz));
}

/* T_set = valor_nuevo; eeprom_save(PAR_TSET, valor_nuevo)
 * UC-02 b: if the EEPROM write fails, the previous value is kept in RAM */
static void task_system_set_param(float valor_nuevo)
{
	float t_set_prev = task_system_dta.t_set;

	task_system_dta.t_set = valor_nuevo;

	if (false == eeprom_save(PAR_TSET, valor_nuevo))
	{
		task_system_dta.t_set = t_set_prev;
		put_event_task_display(EV_DISP_MSG, (int32_t)MSG_EEPROM_ERR);
	}
}

/* operation eeprom_save(p : integer, v : real) */
static bool eeprom_save(system_param_t p, float v)
{
	float t_set = task_system_dta.t_set;
	float t_max = task_system_dta.t_max;

	if (PAR_TSET == p)
		t_set = v;
	else if (PAR_TMAX == p)
		t_max = v;

	return eeprom_write_config(t_set, t_max);
}

/* operation alarm_cause() : integer */
static system_alarm_cause_t alarm_cause(void)
{
	if (task_system_dta.t_medida > task_system_dta.t_max)
		return CAUSA_TEMP;

	return CAUSA_TAPA;
}

/********************** end of file ******************************************/
