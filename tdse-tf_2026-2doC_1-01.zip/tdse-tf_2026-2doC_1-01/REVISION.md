# Estación de Control Ambiental: revisión de statecharts y notas del código

Proyecto STM32CubeIDE para la NUCLEO-F103RB. Tiene la misma estructura que el
ejemplo `tdse-tp2_03-model_integration`: un ejecutor cíclico de 1 ms y una tarea
por statechart. Cada tarea tiene `task_x.c`, `task_x.h`, `task_x_attribute.h` y,
si recibe eventos, `task_x_interface.c/.h` con su cola.

## 1. Mapa statechart → código

| Statechart (repo)        | Tarea                  | Recibe eventos de          |
|--------------------------|------------------------|----------------------------|
| `task_button`            | `task_button.c`        | GPIO (teclado)             |
| *(no hay)*               | `task_sensor.c`        | ADC (LM35, LDR)            |
| `task_system`            | `task_system.c`        | sensor, ui, bluetooth      |
| `task_ui`                | `task_ui.c`            | button, system             |
| `task_display`           | `task_display.c`       | ui, system                 |
| `signaling_statechart`   | `task_signaling.c`     | system, ui                 |
| `actuator_statechart`    | `task_actuator.c`      | signaling, system          |
| `bluetooth_statechart`   | `task_bluetooth.c`     | UART / pin STATE, system   |

El orden en `app.c` es: button, sensor, actuator, display, signaling, ui,
bluetooth, system. Así cada tarea que recibe eventos ya tiene la cola
inicializada cuando otra le manda algo desde su `init`.

## 2. Problemas encontrados en los statecharts y cómo se resolvieron

1. **`task_system` + `task_ui`: el guardado en SET_UP no hacía nada.** En
   `ST_UI_EDIT`, KEY3 levanta `EV_REQ_SET_PARAM : T_edit`. Pero `ST_SET_UP` de
   `task_system` no reacciona a ese evento: solo lo atienden NORMAL y HEATING.
   Además, `EV_REQ_SAVE` estaba declarado y nunca se usaba.
   **Solución:** KEY3 levanta `EV_REQ_SAVE : T_edit`, y `ST_SET_UP` tiene ahora
   `EV_REQ_SAVE / T_set = valor_nuevo; eeprom_save(PAR_TSET, valor_nuevo) -> ST_NORMAL`
   (UC-02, pasos 4 a 6). `EV_REQ_SET_PARAM` queda solo para el BLE.
   → *Hay que corregir los dos diagramas.*

2. **`task_ui`: hay transiciones duplicadas al salir de `ST_UI_SETUP`.**
   - KEY4 aparece como reacción interna (`raise EV_REQ_NORMAL`) y también como
     transición a `ST_UI_MONITOR` con el mismo `raise`. Eso pide el cambio dos
     veces.
   - Con `EV_MODE_CHANGED == MODO_NORMAL` hay dos transiciones al mismo tiempo:
     `ST_UI_SETUP → ST_UI_MONITOR` y `ST_UI_SETUP → ST_UI_NORMAL`. Es no
     determinista.

   **Solución:** KEY4 solo levanta `EV_REQ_NORMAL` y la UI se queda donde está.
   Sale cuando `task_system` confirma con `MODO_NORMAL`, y entra a
   `ST_UI_MONITOR` por su entrada por defecto (`ST_UI_NORMAL`).
   → *Dejar una sola transición en el diagrama.*

3. **`task_ui`: el LCD no se actualizaba en SET_UP ni en ALARMA.** El `every 500 ms`
   está solo en `ST_UI_MONITOR`. En `ST_UI_EDIT`, KEY1 y KEY2 cambian `T_edit`
   pero no hay `EV_UI_REFRESH`, así que el valor nuevo nunca se veía.
   **Solución:** `task_display` redibuja con cada `EV_UI_SCREEN`. Las
   autotransiciones de `ST_UI_EDIT` vuelven a entrar al estado y levantan
   `EV_UI_SCREEN : SCR_SETUP`, lo que también reinicia el `after 10 s`.
   Además, `ST_UI_ALARMA` refresca cada 500 ms para mostrar la temperatura y que
   se sepa cuándo se puede resetear.

4. **`task_display`: el buffer era un placeholder** (`"Hola"`, longitud 4).
   **Solución:** la secuencia tiene 34 posiciones: comando de línea 0, 16
   caracteres, comando de línea 1 y 16 caracteres. Se escribe una posición por
   ms, igual que `after 1 ms [index < length]`. Los eventos que llegan durante
   `ST_WRITE_CHAR` quedan en la cola hasta volver a `ST_IDLE`. Los mensajes
   `MSG_TIMEOUT` y `MSG_EEPROM_ERR` se muestran 2 s y después se vuelve a la
   pantalla normal.

5. **`actuator_statechart`: `DEL_LED_MAX = 5` cuenta eventos `EV_ACT_LED_BLINK`.**
   Con un ejecutor de 1 ms, cada tick funciona como ese evento periódico y
   `DEL_LED_MAX = 500` da un semiperíodo de 500 ms. Se usa para LED_R, LED_G,
   LED_B, RELAY, BUZZER y LD2 (heartbeat en BLINK).

6. **No hay statechart de adquisición, ni nadie que genere `EV_INIT_DONE` /
   `EV_SENSE_TICK`.** Se agregó `task_sensor`: muestrea cada 10 ms, promedia
   10 muestras y manda `EV_SENSE_TICK` cada 100 ms. La primera medición válida
   genera `EV_INIT_DONE`; la EEPROM ya se leyó en `task_system_init`.
   → *Conviene agregar este statechart al repo.*

7. **`bluetooth_statechart`: no dice de dónde salen `linkUp` y `linkDown`.**
   Se usa el pin STATE del HM-10 (PC1) con un antirrebote de 1 s, porque en
   muchos módulos STATE parpadea cuando no hay conexión. Viene **desactivado**
   (`BLE_STATE_PIN_USED = 0` en `board.h`): se asume que el enlace está siempre
   activo y anda aunque no cableen STATE.

8. **`task_system`: prioridad entre guardas.** Cuando con un mismo
   `EV_SENSE_TICK` se cumplen la condición de ALARMA y la de HEATING o NORMAL,
   se evalúa primero la de ALARMA, por seguridad. Conviene marcar esa prioridad
   en el diagrama.

9. **Diferencias con la propuesta que quedaron como en los statecharts:**
   - UC-03 b dice que se vuelve solo a NORMAL; el statechart pide `EV_REQ_RESET`
     (KEY2). Se respetó el statechart.
   - El "salto abrupto" de la LDR se implementa con un umbral
     (`LDR_val > UMBRAL_LUZ`, en cuentas de ADC), no con una derivada.
   - UC-02 b (error de EEPROM): se muestra `ERROR EEPROM` y se mantiene el
     valor anterior en RAM. No hay tono de buzzer porque `signaling` no tiene
     ese evento.
   - El BLE acepta solo los comandos del statechart: `SET_T=xx.x` y
     `MODE=SETUP`. `EV_REQ_RESET` y `EV_REQ_NORMAL` dicen "Teclado o BLE",
     pero no hay comandos para ellos.

## 3. Conexiones (NUCLEO-F103RB)

| Señal               | Pin MCU | Header Arduino | Notas                                         |
|---------------------|---------|----------------|-----------------------------------------------|
| LM35 Vout           | PA0     | A0             | ADC1_IN0                                      |
| LDR                 | PA1     | A1             | LDR a 3V3 y 10 kΩ a GND: más luz = más cuentas |
| KEY1 (SETUP/+/MUTE) | PA8     | D7             | Común del teclado a GND, pull-up interno      |
| KEY2 (-/RESET)      | PB10    | D6             |                                               |
| KEY3 (GUARDAR)      | PB5     | D4             |                                               |
| KEY4 (CANCELAR)     | PC0     | A5             |                                               |
| LED R / G / B       | PA6/PA7/PB6 | D12/D11/D10 | Cátodo común (`LED_RGB_ON` en `board.h`)      |
| Relé                | PB0     | A3             | Si el módulo es activo en bajo: `RELAY_ON = GPIO_PIN_RESET` |
| Buzzer (activo)     | PC7     | D9             |                                               |
| HM-10 RXD           | PA9     | D8             | USART1_TX, 9600 8N1                           |
| HM-10 TXD           | PA10    | D2             | USART1_RX                                     |
| HM-10 STATE         | PC1     | A4             | Opcional (`BLE_STATE_PIN_USED`)               |
| LCD + EEPROM SCL    | PB8     | D15            | I2C1 remapeado, 100 kHz                       |
| LCD + EEPROM SDA    | PB9     | D14            |                                               |
| LD2 (placa)         | PA5     | D13            | Heartbeat                                     |

Direcciones I2C, configurables en `board.h`:
- LCD PCF8574: `0x27`. Si es PCF8574A, usar `0x3F`.
- EEPROM 24C32/24C64/24LC256: `0x50`, con dirección de memoria de 16 bits. Para
  24C02, usar `I2C_MEMADD_SIZE_8BIT`.

## 4. Protocolo Bluetooth

- Telemetría cada 1 s: `T=23.5;L=512;TS=25.0;R=0;M=NORMAL`
- `SET_T=27.5`: responde `ACK` y cambia T_set, que se guarda en EEPROM. El
  rango válido es de 15.0 a 40.0.
- `MODE=SETUP`: responde `ACK` y pasa a SET_UP.
- Cualquier otro comando: `NACK: INVALID_CMD`.
- Alarma: `ALERTA: ALT TEMP!` o `ALERTA: TAPA ABIERTA!`.
- Las líneas terminan en `\r` o `\n` y no se distinguen mayúsculas de minúsculas.

## 5. Tiempos (RNF-01 / RNF-02)

No hay `HAL_Delay` en el super-loop: solo se usa en `lcd_init()`, dentro del
`init`. Las operaciones bloqueantes más largas dentro del loop son estas:
- ADC: 2 canales, unos 50 µs cada 10 ms.
- LCD: un byte por I2C, unos 0.5 ms por ms mientras se redibuja.
- EEPROM: unos 1.1 ms, solo en el momento de guardar. No se espera el ciclo
  interno de escritura de 5 ms.

Pueden medir el WCET por tarea con `task_dta_list[]` en `app.c` (DWT), igual que
en el ejemplo.

## 6. Verificación hecha

- Compila sin warnings con `arm-none-eabi-gcc` 13.2 y `-Wall -Wextra`. Ocupa
  unos 49 KB de flash.
- La lógica de las tareas se probó en la PC con el HAL simulado: 41 casos
  sobre UC-01 a UC-04. Incluyen calefacción con histéresis, SET_UP por teclado
  (guardar, cancelar y timeout), alarma por temperatura y por tapa, mute,
  reset, comandos BLE válidos e inválidos, falla de EEPROM y recuperación de
  T_set después de un reset.
- **Falta probar en la placa** con el hardware real.
