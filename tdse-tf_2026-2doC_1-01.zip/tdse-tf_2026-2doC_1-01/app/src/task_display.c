/*
 * Copyright (c) 2026 Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira
 *           (basado en el template TdSE de Juan Manuel Cruz <jcruz@fi.uba.ar>)
 */

/********************** inclusions *******************************************/
/* Project includes */
#include "main.h"

/* Demo includes */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes */
#include "board.h"
#include "app.h"
#include "lcd.h"
#include "task_system_interface.h"
#include "task_ui_interface.h"
#include "task_display_attribute.h"
#include "task_display_interface.h"

/********************** macros and definitions *******************************/
#define DEL_DISP_MIN		0ul
#define DEL_DISP_CHAR		1ul			/* [ms] after 1 ms / displayDataWrite(buffer[index]) */
#define DEL_DISP_MSG		2000ul		/* [ms] duracion de los mensajes transitorios      */

/********************** internal data declaration ****************************/
task_display_dta_t task_display_dta;

/********************** internal functions declaration ***********************/
void task_display_statechart(void);

static void task_display_start_write(void);
static void task_display_build_buffer(void);
static void task_display_set_line(uint32_t line, const char *p_text);
static void task_display_fmt_temp(char *p_out, uint32_t size, float t);
static void displayDataWrite(uint32_t index);

/********************** internal data definition *****************************/
const char *p_task_display 		= "Task Display (Display Statechart)";
const char *p_task_display_ 	= "Non-Blocking Code";
const char *p_task_display__ 	= "(Update by Time Code, period = 1mS)";

/********************** external data declaration ****************************/

/********************** external functions definition ************************/
void task_display_init(void *parameters)
{
	task_display_dta_t *p_task_display_dta;
	bool b_lcd;

	/* Print out: Task Initialized */
	LOGGER_INFO(" ");
	LOGGER_INFO("  %s is running - Tick [mS] = %lu", GET_NAME(task_display_init), HAL_GetTick());
	LOGGER_INFO("   %s is a %s", GET_NAME(task_display), p_task_display);
	LOGGER_INFO("   %s is a %s", GET_NAME(task_display), p_task_display_);
	LOGGER_INFO("   %s is a %s", GET_NAME(task_display), p_task_display__);

	init_event_task_display();

	/* LCD init (blocking, only here: before the super-loop) */
	b_lcd = lcd_init();
	LOGGER_INFO("   LCD init: %s", (b_lcd ? "ok" : "ERROR (revisar direccion I2C)"));

	/* Update Task Display Data Pointer */
	p_task_display_dta = &task_display_dta;

	p_task_display_dta->tick            = DEL_DISP_MIN;
	p_task_display_dta->event           = EV_DISP_REFRESH;
	p_task_display_dta->value           = 0;
	p_task_display_dta->flag            = false;
	p_task_display_dta->index           = 0;
	p_task_display_dta->length          = DISPLAY_BUFFER_LEN;
	p_task_display_dta->screen          = SCR_INIT;
	p_task_display_dta->msg             = MSG_NONE;
	p_task_display_dta->msg_tick        = DEL_DISP_MIN;
	p_task_display_dta->refresh_pending = false;

	/* Initial transition: Entry -> ST_IDLE */
	p_task_display_dta->state = ST_DISP_IDLE;
}

void task_display_update(void *parameters)
{
	/* Run Task Statechart */
	task_display_statechart();
}

void task_display_statechart(void)
{
	task_display_dta_t *p_task_display_dta;

	/* Update Task Display Data Pointer */
	p_task_display_dta = &task_display_dta;

	/* Transient message timeout */
	if (MSG_NONE != p_task_display_dta->msg)
	{
		if (DEL_DISP_MIN < p_task_display_dta->msg_tick)
		{
			p_task_display_dta->msg_tick--;
		}
		else
		{
			p_task_display_dta->msg = MSG_NONE;
			p_task_display_dta->refresh_pending = true;
		}
	}

	switch (p_task_display_dta->state)
	{
		case ST_DISP_IDLE:

			/* Events are only consumed in ST_IDLE (they stay queued while writing) */
			if (true == any_event_task_display())
			{
				p_task_display_dta->flag = true;
				p_task_display_dta->event = get_event_task_display(&p_task_display_dta->value);
			}

			/* EV_UI_REFRESH / index = 0 */
			if ((true == p_task_display_dta->flag) && (EV_DISP_REFRESH == p_task_display_dta->event))
			{
				p_task_display_dta->flag = false;
				task_display_start_write();
			}
			/* EV_UI_SCREEN : screen  (new screen => redraw) */
			else if ((true == p_task_display_dta->flag) && (EV_DISP_SCREEN == p_task_display_dta->event))
			{
				p_task_display_dta->flag = false;
				p_task_display_dta->screen = (display_scr_t)p_task_display_dta->value;
				task_display_start_write();
			}
			/* EV_UI_MSG : msg  (transient message over the current screen) */
			else if ((true == p_task_display_dta->flag) && (EV_DISP_MSG == p_task_display_dta->event))
			{
				p_task_display_dta->flag = false;
				p_task_display_dta->msg = (display_msg_t)p_task_display_dta->value;
				p_task_display_dta->msg_tick = DEL_DISP_MSG;
				task_display_start_write();
			}
			/* Message expired => redraw the current screen */
			else if (true == p_task_display_dta->refresh_pending)
			{
				task_display_start_write();
			}

			break;

		case ST_DISP_WRITE_CHAR:

			/* [index >= length] -> ST_IDLE */
			if (p_task_display_dta->index >= p_task_display_dta->length)
			{
				p_task_display_dta->state = ST_DISP_IDLE;
			}
			/* after 1 ms [index < length] / displayDataWrite(buffer[index]); index++ */
			else
			{
				if (DEL_DISP_MIN < p_task_display_dta->tick)
				{
					p_task_display_dta->tick--;
				}

				if (DEL_DISP_MIN == p_task_display_dta->tick)
				{
					displayDataWrite(p_task_display_dta->index);
					p_task_display_dta->index++;
					p_task_display_dta->tick = DEL_DISP_CHAR;
				}
			}

			break;

		default:

			p_task_display_dta->flag  = false;
			p_task_display_dta->state = ST_DISP_IDLE;

			break;
	}

	p_task_display_dta->flag = false;
}

/********************** internal functions definition ************************/
static void task_display_start_write(void)
{
	task_display_dta_t *p_task_display_dta = &task_display_dta;

	p_task_display_dta->refresh_pending = false;
	task_display_build_buffer();
	p_task_display_dta->index = 0;
	p_task_display_dta->length = DISPLAY_BUFFER_LEN;
	p_task_display_dta->tick = DEL_DISP_MIN;		/* first char on the next tick */
	p_task_display_dta->state = ST_DISP_WRITE_CHAR;
}

/* Build the two LCD lines from the current screen (or transient message) */
static void task_display_build_buffer(void)
{
	task_display_dta_t *p_task_display_dta = &task_display_dta;
	char tmp[48];		/* set_line() copia solo DISPLAY_COLS */
	char t_str[16];
	char ts_str[16];

	if (MSG_TIMEOUT == p_task_display_dta->msg)
	{
		task_display_set_line(0, "TIEMPO AGOTADO");
		task_display_set_line(1, "Cambios descart.");
		return;
	}

	if (MSG_EEPROM_ERR == p_task_display_dta->msg)
	{
		task_display_set_line(0, "ERROR EEPROM");
		task_display_set_line(1, "No se guardo");
		return;
	}

	task_display_fmt_temp(t_str, sizeof(t_str), get_t_medida_task_system());
	task_display_fmt_temp(ts_str, sizeof(ts_str), get_t_set_task_system());

	switch (p_task_display_dta->screen)
	{
		case SCR_INIT:
			task_display_set_line(0, "EST. AMBIENTAL");
			task_display_set_line(1, "Iniciando...");
			break;

		case SCR_NORMAL:
		case SCR_HEATING:
			snprintf(tmp, sizeof(tmp), "T:%sC Ts:%s", t_str, ts_str);
			task_display_set_line(0, tmp);
			snprintf(tmp, sizeof(tmp), "L:%04lu %s", (unsigned long)get_ldr_val_task_system(),
					 (SCR_HEATING == p_task_display_dta->screen) ? "CALEF ON" : "  NORMAL");
			task_display_set_line(1, tmp);
			break;

		case SCR_SETUP:
			task_display_set_line(0, "SET_UP T objetiv");
			task_display_fmt_temp(ts_str, sizeof(ts_str), get_t_edit_task_ui());
			snprintf(tmp, sizeof(tmp), "Ts:%sC K3=OK", ts_str);
			task_display_set_line(1, tmp);
			break;

		case SCR_ALARMA:
			if (CAUSA_TEMP == get_alarm_cause_task_system())
			{
				task_display_set_line(0, "ALT TEMP!");
			}
			else
			{
				task_display_set_line(0, "TAPA ABIERTA!");
			}
			snprintf(tmp, sizeof(tmp), "T:%sC K2=RST", t_str);
			task_display_set_line(1, tmp);
			break;

		default:
			task_display_set_line(0, "");
			task_display_set_line(1, "");
			break;
	}
}

/* Copy text into a line, padding with spaces up to DISPLAY_COLS */
static void task_display_set_line(uint32_t line, const char *p_text)
{
	uint32_t i;
	char *p_line = task_display_dta.line[line];

	for (i = 0; i < DISPLAY_COLS; i++)
	{
		if ('\0' != *p_text)
			p_line[i] = *p_text++;
		else
			p_line[i] = ' ';
	}
	p_line[DISPLAY_COLS] = '\0';
}

/* Format a temperature as "dd.d" without printf float support */
static void task_display_fmt_temp(char *p_out, uint32_t size, float t)
{
	int32_t tenths = (int32_t)((t >= 0.0f) ? (t * 10.0f + 0.5f) : (t * 10.0f - 0.5f));
	const char *p_sign = (tenths < 0) ? "-" : "";

	if (tenths < 0)
		tenths = -tenths;

	snprintf(p_out, size, "%s%ld.%ld", p_sign, (long)(tenths / 10), (long)(tenths % 10));
}

/* operation displayDataWrite(c : string)
 * Sequence index: 0 = cursor line 0, 1..16 = line 0, 17 = cursor line 1, 18..33 = line 1 */
static void displayDataWrite(uint32_t index)
{
	if (0 == index)
	{
		lcd_write_cmd(LCD_CMD_LINE_0);
	}
	else if (index <= DISPLAY_COLS)
	{
		lcd_write_data((uint8_t)task_display_dta.line[0][index - 1]);
	}
	else if ((DISPLAY_COLS + 1) == index)
	{
		lcd_write_cmd(LCD_CMD_LINE_1);
	}
	else
	{
		lcd_write_data((uint8_t)task_display_dta.line[1][index - DISPLAY_COLS - 2]);
	}
}

/********************** end of file ******************************************/
