/*
 * Copyright (c) 2026 Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira
 *           (basado en el template TdSE de Juan Manuel Cruz <jcruz@fi.uba.ar>)
 */

/********************** inclusions *******************************************/
/* Project includes */
#include "main.h"

/* Demo includes */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes */
#include "board.h"
#include "app.h"
#include "ble_uart.h"

/********************** macros and definitions *******************************/
#define BLE_RX_BUF_SIZE		(64ul)
#define BLE_TX_BUF_SIZE		(256ul)

/********************** internal data declaration ****************************/

/********************** internal functions declaration ***********************/
static void ble_uart_start_tx(void);

/********************** internal data definition *****************************/
static uint8_t			ble_rx_byte;
static uint8_t			ble_rx_buf[BLE_RX_BUF_SIZE];
static volatile uint32_t	ble_rx_head;		/* written by ISR       */
static volatile uint32_t	ble_rx_tail;		/* written by main loop */

static uint8_t			ble_tx_buf[BLE_TX_BUF_SIZE];
static volatile uint32_t	ble_tx_head;		/* written by main loop */
static volatile uint32_t	ble_tx_tail;		/* written by ISR       */
static volatile uint32_t	ble_tx_inflight;
static volatile bool		ble_tx_busy;

/********************** external data declaration ****************************/

/********************** external functions definition ************************/
void ble_uart_init(void)
{
	ble_rx_head = 0;
	ble_rx_tail = 0;
	ble_tx_head = 0;
	ble_tx_tail = 0;
	ble_tx_inflight = 0;
	ble_tx_busy = false;

	HAL_UART_Receive_IT(&huart1, &ble_rx_byte, 1);
}

bool ble_uart_read_byte(uint8_t *p_byte)
{
	if (ble_rx_head == ble_rx_tail)
		return false;

	*p_byte = ble_rx_buf[ble_rx_tail];
	ble_rx_tail = (ble_rx_tail + 1) % BLE_RX_BUF_SIZE;

	return true;
}

/* Copies the string into the TX ring buffer (drops it if there is no room) */
bool ble_uart_write(const char *p_str)
{
	uint32_t len = strlen(p_str);
	uint32_t free_space;
	uint32_t i;

	__asm("CPSID i");	/* disable interrupts */

	free_space = (BLE_TX_BUF_SIZE - 1) - ((ble_tx_head + BLE_TX_BUF_SIZE - ble_tx_tail) % BLE_TX_BUF_SIZE);

	if (len > free_space)
	{
		__asm("CPSIE i");	/* enable interrupts */
		return false;
	}

	for (i = 0; i < len; i++)
	{
		ble_tx_buf[ble_tx_head] = (uint8_t)p_str[i];
		ble_tx_head = (ble_tx_head + 1) % BLE_TX_BUF_SIZE;
	}

	if (false == ble_tx_busy)
		ble_uart_start_tx();

	__asm("CPSIE i");	/* enable interrupts */

	return true;
}

/* Called from HAL_UART_RxCpltCallback (app_it.c) */
void ble_uart_rx_cplt_isr(void)
{
	uint32_t next = (ble_rx_head + 1) % BLE_RX_BUF_SIZE;

	/* Buffer full: the byte is lost */
	if (next != ble_rx_tail)
	{
		ble_rx_buf[ble_rx_head] = ble_rx_byte;
		ble_rx_head = next;
	}

	HAL_UART_Receive_IT(&huart1, &ble_rx_byte, 1);
}

/* Called from HAL_UART_TxCpltCallback (app_it.c) */
void ble_uart_tx_cplt_isr(void)
{
	ble_tx_tail = (ble_tx_tail + ble_tx_inflight) % BLE_TX_BUF_SIZE;
	ble_tx_inflight = 0;
	ble_uart_start_tx();
}

/* Called from HAL_UART_ErrorCallback (app_it.c): overrun, noise, etc. */
void ble_uart_error_isr(void)
{
	HAL_UART_Receive_IT(&huart1, &ble_rx_byte, 1);
}

/********************** internal functions definition ************************/
/* Starts the transmission of the contiguous chunk at the tail (interrupts disabled or ISR) */
static void ble_uart_start_tx(void)
{
	uint32_t len;

	if (ble_tx_head == ble_tx_tail)
	{
		ble_tx_busy = false;
		return;
	}

	if (ble_tx_head > ble_tx_tail)
		len = ble_tx_head - ble_tx_tail;
	else
		len = BLE_TX_BUF_SIZE - ble_tx_tail;

	ble_tx_inflight = len;
	ble_tx_busy = true;

	if (HAL_OK != HAL_UART_Transmit_IT(&huart1, &ble_tx_buf[ble_tx_tail], (uint16_t)len))
	{
		ble_tx_inflight = 0;
		ble_tx_busy = false;
	}
}

/********************** end of file ******************************************/
