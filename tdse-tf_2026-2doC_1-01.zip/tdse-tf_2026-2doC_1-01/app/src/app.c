/*
 * Copyright (c) 2026 Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>
 */

/********************** inclusions *******************************************/
/* Project includes */
#include "main.h"

/* Demo includes */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes */
#include "board.h"
#include "app_it.h"
#include "task_button.h"
#include "task_sensor.h"
#include "task_actuator.h"
#include "task_display.h"
#include "task_signaling.h"
#include "task_ui.h"
#include "task_bluetooth.h"
#include "task_system.h"

/********************** macros and definitions *******************************/
#define TASK_X_NOE_INI		0ul
#define TASK_X_LET_INI		0ul
#define TASK_X_BCET_INI		1000ul
#define TASK_X_WCET_INI		0ul
#define TASK_X_DELAY_MIN	0ul

typedef struct {
	void (*task_init)(void *);		// Pointer to task (must be a
									// 'void (void *)' function)
	void (*task_update)(void *);	// Pointer to task (must be a
									// 'void (void *)' function)
	void *parameters;				// Pointer to parameters
} task_cfg_t;

typedef struct {
    uint32_t NOE;		// Number of execution (numeral)
    uint32_t LET;		// Last execution time (microseconds)
    uint32_t BCET;		// Best-case execution time (microseconds)
    uint32_t WCET;		// Worst-case execution time (microseconds)
} task_dta_t;

/********************** internal data declaration ****************************/
/* The order matters only for the init: every task that receives events must
 * be initialized (its queue cleared) before a task that can send it events
 * during its own init (task_ui -> task_display, task_signaling -> task_actuator,
 * task_system -> task_ui / task_signaling / task_actuator).                   */
const task_cfg_t task_cfg_list[]	= {
		{task_button_init, 		task_button_update, 	NULL},
		{task_sensor_init, 		task_sensor_update, 	NULL},
		{task_actuator_init,	task_actuator_update, 	NULL},
		{task_display_init,		task_display_update, 	NULL},
		{task_signaling_init,	task_signaling_update, 	NULL},
		{task_ui_init,			task_ui_update, 		NULL},
		{task_bluetooth_init,	task_bluetooth_update, 	NULL},
		{task_system_init, 		task_system_update, 	NULL}
};

#define TASK_QTY	(sizeof(task_cfg_list)/sizeof(task_cfg_t))

/********************** internal functions declaration ***********************/

/********************** internal data definition *****************************/
const char *p_app	= "Bare Metal - Event-Triggered Systems (ETS)";
const char *p_app_	= "App - Estacion de Control Ambiental";
const char *p_app__	= "(Update by Time Code, period = 1mS)";

/********************** external data declaration ****************************/
uint32_t g_app_cnt;
uint32_t g_app_runtime_us;

task_dta_t task_dta_list[TASK_QTY];

/********************** external functions definition ************************/
void app_init(void)
{
	uint32_t index;

	/* Print out: Application Initialized */
	LOGGER_INFO(" ");
	LOGGER_INFO("%s is running - Tick [mS] = %lu", GET_NAME(app_init), HAL_GetTick());

	LOGGER_INFO(" %s is a %s", GET_NAME(app), p_app);
	LOGGER_INFO(" %s is a %s", GET_NAME(app), p_app_);
	LOGGER_INFO(" %s is a %s", GET_NAME(app), p_app__);

	/* Init & Print out: Application execution counter */
	g_app_cnt = ZERO;
	LOGGER_INFO(" %s = %lu", GET_NAME(g_app_cnt), g_app_cnt);

	/* Init Cycle Counter */
	cycle_counter_init();

    /* Go through the task arrays */
	for (index = 0; TASK_QTY > index; index++)
	{
		/* Run task_x_init */
		(*task_cfg_list[index].task_init)(task_cfg_list[index].parameters);

		/* Init variables */
		task_dta_list[index].NOE = TASK_X_NOE_INI;
		task_dta_list[index].LET = TASK_X_LET_INI;
		task_dta_list[index].BCET = TASK_X_BCET_INI;
		task_dta_list[index].WCET = TASK_X_WCET_INI;
	}

  	/* Application Interrupts Init */
	app_it_init();
}

void app_update(void)
{
	uint32_t index;
	bool b_time_update_required = false;

	/* Protect shared resource */
	__asm("CPSID i");	/* disable interrupts */
    if (ZERO < g_app_tick_cnt)
    {
		/* Update Tick Counter */
    	g_app_tick_cnt--;
    	b_time_update_required = true;
    }
    __asm("CPSIE i");	/* enable interrupts */

	/* Check if it's time to run tasks */
    while (b_time_update_required)
    {
    	/* Update App Counter */
    	g_app_cnt++;
    	g_app_runtime_us = 0;

		/* Go through the task arrays */
		for (index = 0; TASK_QTY > index; index++)
		{
			cycle_counter_reset();

    		/* Run task_x_update */
			(*task_cfg_list[index].task_update)(task_cfg_list[index].parameters);

			/* Update variables */
			task_dta_list[index].NOE++;

			task_dta_list[index].LET = cycle_counter_get_time_us();

			if (task_dta_list[index].BCET > task_dta_list[index].LET)
			{
				task_dta_list[index].BCET = task_dta_list[index].LET;
			}

			if (task_dta_list[index].WCET < task_dta_list[index].LET)
			{
				task_dta_list[index].WCET = task_dta_list[index].LET;
			}

			g_app_runtime_us += task_dta_list[index].LET;
		}
//		HAL_PWR_EnterSLEEPMode(0, PWR_SLEEPENTRY_WFI);

		/* Protect shared resource */
		__asm("CPSID i");	/* disable interrupts */
		if (ZERO < g_app_tick_cnt)
		{
			/* Update Tick Counter */
			g_app_tick_cnt--;
			b_time_update_required = true;
		}
		else
		{
			b_time_update_required = false;
		}
		__asm("CPSIE i");	/* enable interrupts */
	}
}

/********************** end of file ******************************************/
