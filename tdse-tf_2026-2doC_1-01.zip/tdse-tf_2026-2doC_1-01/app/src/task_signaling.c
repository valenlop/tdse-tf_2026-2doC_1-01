/*
 * Copyright (c) 2026 Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira
 *           (basado en el template TdSE de Juan Manuel Cruz <jcruz@fi.uba.ar>)
 */

/********************** inclusions *******************************************/
/* Project includes */
#include "main.h"

/* Demo includes */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes */
#include "board.h"
#include "app.h"
#include "task_system_interface.h"
#include "task_actuator_attribute.h"
#include "task_actuator_interface.h"
#include "task_signaling_attribute.h"
#include "task_signaling_interface.h"

/********************** macros and definitions *******************************/
#define DEL_SIG_MIN			0ul
#define DEL_SIG_BLINK		500ul		/* [ms] every 500 ms (UC-03: 500 ms ON / 500 ms OFF) */

/********************** internal data declaration ****************************/
task_signaling_dta_t task_signaling_dta;

/********************** internal functions declaration ***********************/
void task_signaling_statechart(void);

static void task_signaling_enter(task_signaling_st_t state);
static void task_signaling_exit(task_signaling_st_t state);
static void task_signaling_transition(task_signaling_st_t state);

/* Out events -> hardware drivers (task_actuator) */
static void raise_led_rgb(signaling_color_t color);		/* EV_LED_RGB   : integer */
static void raise_relay_hw(bool on);						/* EV_RELAY_HW  : boolean */
static void raise_buzzer_hw(bool on);						/* EV_BUZZER_HW : boolean */

/********************** internal data definition *****************************/
const char *p_task_signaling 	= "Task Signaling (Signaling Statechart)";
const char *p_task_signaling_ 	= "Non-Blocking Code";
const char *p_task_signaling__ 	= "(Update by Time Code, period = 1mS)";

/********************** external data declaration ****************************/

/********************** external functions definition ************************/
void task_signaling_init(void *parameters)
{
	task_signaling_dta_t *p_task_signaling_dta;

	/* Print out: Task Initialized */
	LOGGER_INFO(" ");
	LOGGER_INFO("  %s is running - Tick [mS] = %lu", GET_NAME(task_signaling_init), HAL_GetTick());
	LOGGER_INFO("   %s is a %s", GET_NAME(task_signaling), p_task_signaling);
	LOGGER_INFO("   %s is a %s", GET_NAME(task_signaling), p_task_signaling_);
	LOGGER_INFO("   %s is a %s", GET_NAME(task_signaling), p_task_signaling__);

	init_event_task_signaling();

	/* Update Task Signaling Data Pointer */
	p_task_signaling_dta = &task_signaling_dta;

	p_task_signaling_dta->tick         = DEL_SIG_MIN;
	p_task_signaling_dta->event        = EV_SIG_MODE_CHANGED;
	p_task_signaling_dta->value        = 0;
	p_task_signaling_dta->flag         = false;
	p_task_signaling_dta->led_on       = false;
	p_task_signaling_dta->buzzer_muted = false;

	/* Initial transition: Entry -> ST_INIT */
	task_signaling_enter(ST_SIG_INIT);
}

void task_signaling_update(void *parameters)
{
	/* Run Task Statechart */
	task_signaling_statechart();
}

void task_signaling_statechart(void)
{
	task_signaling_dta_t *p_task_signaling_dta;
	bool b_mode_changed;
	int32_t modo;

	/* Update Task Signaling Data Pointer */
	p_task_signaling_dta = &task_signaling_dta;

	if (true == any_event_task_signaling())
	{
		p_task_signaling_dta->flag = true;
		p_task_signaling_dta->event = get_event_task_signaling(&p_task_signaling_dta->value);
	}

	b_mode_changed = (true == p_task_signaling_dta->flag) && (EV_SIG_MODE_CHANGED == p_task_signaling_dta->event);
	modo = p_task_signaling_dta->value;

	switch (p_task_signaling_dta->state)
	{
		case ST_SIG_INIT:

			if (b_mode_changed && (MODO_NORMAL == modo))
				task_signaling_transition(ST_SIG_NORMAL);

			break;

		case ST_SIG_NORMAL:

			if (b_mode_changed && (MODO_SETUP == modo))
				task_signaling_transition(ST_SIG_SET_UP);
			else if (b_mode_changed && (MODO_HEATING == modo))
				task_signaling_transition(ST_SIG_HEATING);
			else if (b_mode_changed && (MODO_ALARMA == modo))
				task_signaling_transition(ST_SIG_ALARMA);

			break;

		case ST_SIG_HEATING:

			if (b_mode_changed && (MODO_SETUP == modo))
				task_signaling_transition(ST_SIG_SET_UP);
			else if (b_mode_changed && (MODO_NORMAL == modo))
				task_signaling_transition(ST_SIG_NORMAL);
			else if (b_mode_changed && (MODO_ALARMA == modo))
				task_signaling_transition(ST_SIG_ALARMA);

			break;

		case ST_SIG_SET_UP:

			if (b_mode_changed && (MODO_NORMAL == modo))
				task_signaling_transition(ST_SIG_NORMAL);
			else if (b_mode_changed && (MODO_ALARMA == modo))
				task_signaling_transition(ST_SIG_ALARMA);

			break;

		case ST_SIG_ALARMA:

			/* ST_ALARMA -> ST_NORMAL */
			if (b_mode_changed && (MODO_NORMAL == modo))
			{
				task_signaling_transition(ST_SIG_NORMAL);
				break;
			}

			/* EV_REQ_MUTE / buzzerMuted = true; raise EV_BUZZER_HW : false */
			if ((true == p_task_signaling_dta->flag) && (EV_SIG_REQ_MUTE == p_task_signaling_dta->event))
			{
				p_task_signaling_dta->buzzer_muted = true;
				raise_buzzer_hw(false);
			}

			/* every 500 ms [ledOn]  / ledOn = false; raise EV_LED_RGB : 0; raise EV_BUZZER_HW : false
			 * every 500 ms [!ledOn] / ledOn = true;  raise EV_LED_RGB : 4; raise EV_BUZZER_HW : !buzzerMuted */
			if (DEL_SIG_MIN < p_task_signaling_dta->tick)
			{
				p_task_signaling_dta->tick--;
			}

			if (DEL_SIG_MIN == p_task_signaling_dta->tick)
			{
				p_task_signaling_dta->tick = DEL_SIG_BLINK;

				if (true == p_task_signaling_dta->led_on)
				{
					p_task_signaling_dta->led_on = false;
					raise_led_rgb(COLOR_OFF);
					raise_buzzer_hw(false);
				}
				else
				{
					p_task_signaling_dta->led_on = true;
					raise_led_rgb(COLOR_ROJO);
					raise_buzzer_hw(!p_task_signaling_dta->buzzer_muted);
				}
			}

			break;

		default:

			task_signaling_enter(ST_SIG_INIT);

			break;
	}

	/* Events are consumed (or discarded) in each run */
	p_task_signaling_dta->flag = false;
}

/********************** internal functions definition ************************/
static void task_signaling_transition(task_signaling_st_t state)
{
	task_signaling_exit(task_signaling_dta.state);
	task_signaling_enter(state);
}

static void task_signaling_exit(task_signaling_st_t state)
{
	/* ST_ALARMA: exit / raise EV_BUZZER_HW : false */
	if (ST_SIG_ALARMA == state)
	{
		raise_buzzer_hw(false);
	}
}

static void task_signaling_enter(task_signaling_st_t state)
{
	task_signaling_dta_t *p_task_signaling_dta = &task_signaling_dta;

	p_task_signaling_dta->state = state;

	switch (state)
	{
		case ST_SIG_INIT:
			raise_led_rgb(COLOR_OFF);
			raise_relay_hw(false);
			raise_buzzer_hw(false);
			break;

		case ST_SIG_NORMAL:
			raise_led_rgb(COLOR_VERDE);
			raise_relay_hw(false);
			raise_buzzer_hw(false);
			break;

		case ST_SIG_HEATING:
			raise_led_rgb(COLOR_AZUL);
			raise_relay_hw(true);
			raise_buzzer_hw(false);
			break;

		case ST_SIG_SET_UP:
			raise_led_rgb(COLOR_AMARILLO);
			raise_relay_hw(false);
			raise_buzzer_hw(false);
			break;

		case ST_SIG_ALARMA:
			raise_relay_hw(false);
			p_task_signaling_dta->buzzer_muted = false;
			p_task_signaling_dta->led_on = true;
			raise_led_rgb(COLOR_ROJO);
			raise_buzzer_hw(true);
			p_task_signaling_dta->tick = DEL_SIG_BLINK;
			break;

		default:
			break;
	}
}

/* EV_LED_RGB: 0 OFF, 1 Verde, 2 Azul, 3 Amarillo (R+G), 4 Rojo */
static void raise_led_rgb(signaling_color_t color)
{
	bool r = (COLOR_ROJO == color) || (COLOR_AMARILLO == color);
	bool g = (COLOR_VERDE == color) || (COLOR_AMARILLO == color);
	bool b = (COLOR_AZUL == color);

	put_event_task_actuator(r ? EV_ACT_LED_ON : EV_ACT_LED_OFF, ID_LED_R);
	put_event_task_actuator(g ? EV_ACT_LED_ON : EV_ACT_LED_OFF, ID_LED_G);
	put_event_task_actuator(b ? EV_ACT_LED_ON : EV_ACT_LED_OFF, ID_LED_B);
}

static void raise_relay_hw(bool on)
{
	put_event_task_actuator(on ? EV_ACT_LED_ON : EV_ACT_LED_OFF, ID_RELAY);
}

static void raise_buzzer_hw(bool on)
{
	put_event_task_actuator(on ? EV_ACT_LED_ON : EV_ACT_LED_OFF, ID_BUZZER);
}

/********************** end of file ******************************************/
