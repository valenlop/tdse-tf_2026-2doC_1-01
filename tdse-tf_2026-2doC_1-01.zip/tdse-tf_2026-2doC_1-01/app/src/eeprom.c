/*
 * Copyright (c) 2026 Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira
 *           (basado en el template TdSE de Juan Manuel Cruz <jcruz@fi.uba.ar>)
 */

/********************** inclusions *******************************************/
/* Project includes */
#include "main.h"

/* Demo includes */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes */
#include "board.h"
#include "app.h"
#include "eeprom.h"

/********************** macros and definitions *******************************/
#define EEPROM_CFG_ADDR		(0x0000)	/* inicio de pagina: el registro no cruza paginas */
#define EEPROM_CFG_LEN		(8ul)
#define EEPROM_MAGIC_0		(0xA5)
#define EEPROM_MAGIC_1		(0x5A)
#define EEPROM_I2C_TIMEOUT	(5ul)		/* [ms] */

/* Registro: [0..1] magic | [2..3] T_set (int16, decimas) | [4..5] T_max | [6] checksum | [7] 0 */

/********************** internal data declaration ****************************/

/********************** internal functions declaration ***********************/
static uint8_t eeprom_checksum(const uint8_t *p_buf, uint32_t len);
static int16_t to_tenths(float t);

/********************** internal data definition *****************************/

/********************** external data declaration ****************************/

/********************** external functions definition ************************/
bool eeprom_read_config(float *p_t_set, float *p_t_max)
{
	uint8_t buf[EEPROM_CFG_LEN];
	int16_t t_set, t_max;

	if (HAL_OK != HAL_I2C_Mem_Read(&hi2c1, EEPROM_I2C_ADDR, EEPROM_CFG_ADDR, EEPROM_MEM_ADD_SIZE,
								   buf, EEPROM_CFG_LEN, EEPROM_I2C_TIMEOUT))
		return false;

	if ((EEPROM_MAGIC_0 != buf[0]) || (EEPROM_MAGIC_1 != buf[1]))
		return false;

	if (eeprom_checksum(buf, 6) != buf[6])
		return false;

	t_set = (int16_t)((uint16_t)buf[2] | ((uint16_t)buf[3] << 8));
	t_max = (int16_t)((uint16_t)buf[4] | ((uint16_t)buf[5] << 8));

	*p_t_set = (float)t_set / 10.0f;
	*p_t_max = (float)t_max / 10.0f;

	return true;
}

bool eeprom_write_config(float t_set, float t_max)
{
	uint8_t buf[EEPROM_CFG_LEN];
	int16_t ts = to_tenths(t_set);
	int16_t tm = to_tenths(t_max);

	buf[0] = EEPROM_MAGIC_0;
	buf[1] = EEPROM_MAGIC_1;
	buf[2] = (uint8_t)((uint16_t)ts & 0xFF);
	buf[3] = (uint8_t)((uint16_t)ts >> 8);
	buf[4] = (uint8_t)((uint16_t)tm & 0xFF);
	buf[5] = (uint8_t)((uint16_t)tm >> 8);
	buf[6] = eeprom_checksum(buf, 6);
	buf[7] = 0;

	/* ~1 ms at 100 kHz; the internal write cycle (~5 ms) is not awaited */
	return (HAL_OK == HAL_I2C_Mem_Write(&hi2c1, EEPROM_I2C_ADDR, EEPROM_CFG_ADDR, EEPROM_MEM_ADD_SIZE,
										buf, EEPROM_CFG_LEN, EEPROM_I2C_TIMEOUT));
}

/********************** internal functions definition ************************/
static uint8_t eeprom_checksum(const uint8_t *p_buf, uint32_t len)
{
	uint8_t sum = 0;
	uint32_t i;

	for (i = 0; i < len; i++)
		sum += p_buf[i];

	return (uint8_t)(~sum);
}

static int16_t to_tenths(float t)
{
	return (int16_t)((t >= 0.0f) ? (t * 10.0f + 0.5f) : (t * 10.0f - 0.5f));
}

/********************** end of file ******************************************/
