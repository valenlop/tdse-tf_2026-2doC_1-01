/*
 * Copyright (c) 2026 Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira
 *           (basado en el template TdSE de Juan Manuel Cruz <jcruz@fi.uba.ar>)
 */

/********************** inclusions *******************************************/
/* Project includes */
#include "main.h"

/* Demo includes */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes */
#include "board.h"
#include "app.h"
#include "task_ui_interface.h"
#include "task_button_attribute.h"

/********************** macros and definitions *******************************/
#define DEL_BTN_MIN		0ul
#define DEL_BTN_DOWN	20ul		/* [ms] statechart task_button: DEL_BTN_DOWN */
#define DEL_BTN_UP		20ul		/* [ms] statechart task_button: DEL_BTN_UP   */

#define BUTTON_CFG_QTY	(sizeof(task_button_cfg_list)/sizeof(task_button_cfg_t))
#define BUTTON_DTA_QTY	BUTTON_CFG_QTY

/********************** internal data declaration ****************************/
const task_button_cfg_t task_button_cfg_list[] = {
	{ID_KEY1, KEY1_PORT, KEY1_PIN, KEY1_PRESSED, DEL_BTN_DOWN, DEL_BTN_UP, EV_UI_KEY1_PRESSED, EV_UI_KEY1_RELEASED},
	{ID_KEY2, KEY2_PORT, KEY2_PIN, KEY2_PRESSED, DEL_BTN_DOWN, DEL_BTN_UP, EV_UI_KEY2_PRESSED, EV_UI_KEY2_RELEASED},
	{ID_KEY3, KEY3_PORT, KEY3_PIN, KEY3_PRESSED, DEL_BTN_DOWN, DEL_BTN_UP, EV_UI_KEY3_PRESSED, EV_UI_KEY3_RELEASED},
	{ID_KEY4, KEY4_PORT, KEY4_PIN, KEY4_PRESSED, DEL_BTN_DOWN, DEL_BTN_UP, EV_UI_KEY4_PRESSED, EV_UI_KEY4_RELEASED}
};

task_button_dta_t task_button_dta_list[BUTTON_DTA_QTY];

/********************** internal functions declaration ***********************/
void task_button_statechart(uint32_t index);

/********************** internal data definition *****************************/
const char *p_task_button 		= "Task Button (Button Statechart)";
const char *p_task_button_ 		= "Non-Blocking Code";
const char *p_task_button__ 	= "(Update by Time Code, period = 1mS)";

/********************** external data declaration ****************************/

/********************** external functions definition ************************/
void task_button_init(void *parameters)
{
	uint32_t index;
	task_button_dta_t *p_task_button_dta;
	task_button_st_t state;
	task_button_ev_t event;

	/* Print out: Task Initialized */
	LOGGER_INFO(" ");
	LOGGER_INFO("  %s is running - Tick [mS] = %lu", GET_NAME(task_button_init), HAL_GetTick());
	LOGGER_INFO("   %s is a %s", GET_NAME(task_button), p_task_button);
	LOGGER_INFO("   %s is a %s", GET_NAME(task_button), p_task_button_);
	LOGGER_INFO("   %s is a %s", GET_NAME(task_button), p_task_button__);

	for (index = 0; BUTTON_DTA_QTY > index; index++)
	{
		/* Update Task Button Data Pointer */
		p_task_button_dta = &task_button_dta_list[index];

		/* Init & Print out: Index & Task execution FSM */
		state = ST_BTN_UP;
		p_task_button_dta->state = state;

		event = EV_BTN_UP;
		p_task_button_dta->event = event;

		p_task_button_dta->tick = DEL_BTN_MIN;

		LOGGER_INFO(" ");
		LOGGER_INFO("   %s = %lu   %s = %lu   %s = %lu",
				    GET_NAME(index), index,
					GET_NAME(state), (uint32_t)state,
					GET_NAME(event), (uint32_t)event);
	}
}

void task_button_update(void *parameters)
{
	uint32_t index;

	for (index = 0; BUTTON_DTA_QTY > index; index++)
	{
		/* Run Task Statechart */
		task_button_statechart(index);
	}
}

void task_button_statechart(uint32_t index)
{
	const task_button_cfg_t *p_task_button_cfg;
	task_button_dta_t *p_task_button_dta;

	/* Update Task Button Configuration & Data Pointer */
	p_task_button_cfg = &task_button_cfg_list[index];
	p_task_button_dta = &task_button_dta_list[index];

	/* Generate event from GPIO (EV_BTN_DOWN / EV_BTN_UP every tick) */
	if (p_task_button_cfg->pressed == HAL_GPIO_ReadPin(p_task_button_cfg->gpio_port, p_task_button_cfg->pin))
	{
		p_task_button_dta->event = EV_BTN_DOWN;
	}
	else
	{
		p_task_button_dta->event = EV_BTN_UP;
	}

	switch (p_task_button_dta->state)
	{
		case ST_BTN_UP:

			/* EV_BTN_DOWN / tick = 0 */
			if (EV_BTN_DOWN == p_task_button_dta->event)
			{
				p_task_button_dta->tick = DEL_BTN_MIN;
				p_task_button_dta->state = ST_BTN_FALLING;
			}

			break;

		case ST_BTN_FALLING:

			if (EV_BTN_DOWN == p_task_button_dta->event)
			{
				/* EV_BTN_DOWN [tick < DEL_BTN_DOWN] / tick = tick + 1 */
				if (p_task_button_cfg->tick_max_down > p_task_button_dta->tick)
				{
					p_task_button_dta->tick++;
				}
				/* EV_BTN_DOWN [tick >= DEL_BTN_DOWN] / raise EV_SYS_BTN_PRESSED */
				else
				{
					put_event_task_ui(p_task_button_cfg->signal_pressed, 0);
					p_task_button_dta->state = ST_BTN_DOWN;
				}
			}
			/* EV_BTN_UP */
			else
			{
				p_task_button_dta->state = ST_BTN_UP;
			}

			break;

		case ST_BTN_DOWN:

			/* EV_BTN_UP / tick = 0 */
			if (EV_BTN_UP == p_task_button_dta->event)
			{
				p_task_button_dta->tick = DEL_BTN_MIN;
				p_task_button_dta->state = ST_BTN_RISING;
			}

			break;

		case ST_BTN_RISING:

			if (EV_BTN_UP == p_task_button_dta->event)
			{
				/* EV_BTN_UP [tick < DEL_BTN_UP] / tick = tick + 1 */
				if (p_task_button_cfg->tick_max_up > p_task_button_dta->tick)
				{
					p_task_button_dta->tick++;
				}
				/* EV_BTN_UP [tick >= DEL_BTN_UP] / raise EV_SYS_BTN_RELEASED */
				else
				{
					put_event_task_ui(p_task_button_cfg->signal_released, 0);
					p_task_button_dta->state = ST_BTN_UP;
				}
			}
			/* EV_BTN_DOWN */
			else
			{
				p_task_button_dta->state = ST_BTN_DOWN;
			}

			break;

		default:

			p_task_button_dta->tick  = DEL_BTN_MIN;
			p_task_button_dta->state = ST_BTN_UP;
			p_task_button_dta->event = EV_BTN_UP;

			break;
	}
}

/********************** end of file ******************************************/
