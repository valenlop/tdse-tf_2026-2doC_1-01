/*
 * Copyright (c) 2026 Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira
 *           (basado en el template TdSE de Juan Manuel Cruz <jcruz@fi.uba.ar>)
 */

/********************** inclusions *******************************************/
/* Project includes */
#include "main.h"

/* Demo includes */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes */
#include "board.h"
#include "app.h"
#include "task_system_interface.h"
#include "task_sensor_attribute.h"
#include "task_sensor_interface.h"

/********************** macros and definitions *******************************/
/* Cada DEL_SEN_SAMPLE ms se convierten ambos canales (~50 uS en total con
 * 239.5 ciclos de muestreo a 10.67 MHz). Se promedian SENSOR_AVG_QTY muestras
 * y al completar el promedio se genera EV_SENSE_TICK (cada 100 ms).            */
#define DEL_SEN_MIN			0ul
#define DEL_SEN_SAMPLE		10ul
#define SENSOR_AVG_QTY		10ul
#define ADC_POLL_TIMEOUT	1ul		/* [ms] */

#define SENSOR_CFG_QTY		(sizeof(task_sensor_cfg_list)/sizeof(task_sensor_cfg_t))
#define SENSOR_DTA_QTY		SENSOR_CFG_QTY

/********************** internal data declaration ****************************/
const task_sensor_cfg_t task_sensor_cfg_list[] = {
	{ID_LM35,	LM35_ADC_CHANNEL},
	{ID_LDR,	LDR_ADC_CHANNEL}
};

task_sensor_dta_t task_sensor_dta_list[SENSOR_DTA_QTY];

/********************** internal functions declaration ***********************/
static uint32_t task_sensor_adc_read(uint32_t channel);

/********************** internal data definition *****************************/
const char *p_task_sensor 		= "Task Sensor (ADC: LM35 + LDR)";
const char *p_task_sensor_ 		= "Non-Blocking Code";
const char *p_task_sensor__ 	= "(Update by Time Code, period = 1mS)";

static uint32_t task_sensor_tick;
static uint32_t task_sensor_samples;
static bool		task_sensor_first;

/********************** external data declaration ****************************/

/********************** external functions definition ************************/
void task_sensor_init(void *parameters)
{
	uint32_t index;

	/* Print out: Task Initialized */
	LOGGER_INFO(" ");
	LOGGER_INFO("  %s is running - Tick [mS] = %lu", GET_NAME(task_sensor_init), HAL_GetTick());
	LOGGER_INFO("   %s is a %s", GET_NAME(task_sensor), p_task_sensor);
	LOGGER_INFO("   %s is a %s", GET_NAME(task_sensor), p_task_sensor_);
	LOGGER_INFO("   %s is a %s", GET_NAME(task_sensor), p_task_sensor__);

	/* ADC self-calibration (STM32F1) */
	HAL_ADCEx_Calibration_Start(&hadc1);

	for (index = 0; SENSOR_DTA_QTY > index; index++)
	{
		task_sensor_dta_list[index].acc = 0;
		task_sensor_dta_list[index].raw = 0;
	}

	task_sensor_tick = DEL_SEN_SAMPLE;
	task_sensor_samples = 0;
	task_sensor_first = true;
}

void task_sensor_update(void *parameters)
{
	uint32_t index;
	task_sensor_dta_t *p_task_sensor_dta;

	if (DEL_SEN_MIN < task_sensor_tick)
	{
		task_sensor_tick--;
		return;
	}
	task_sensor_tick = DEL_SEN_SAMPLE;

	/* Sample all channels */
	for (index = 0; SENSOR_DTA_QTY > index; index++)
	{
		p_task_sensor_dta = &task_sensor_dta_list[index];
		p_task_sensor_dta->acc += task_sensor_adc_read(task_sensor_cfg_list[index].adc_channel);
	}
	task_sensor_samples++;

	/* Average ready => notify Task System */
	if (SENSOR_AVG_QTY <= task_sensor_samples)
	{
		for (index = 0; SENSOR_DTA_QTY > index; index++)
		{
			p_task_sensor_dta = &task_sensor_dta_list[index];
			p_task_sensor_dta->raw = p_task_sensor_dta->acc / SENSOR_AVG_QTY;
			p_task_sensor_dta->acc = 0;
		}
		task_sensor_samples = 0;

		if (true == task_sensor_first)
		{
			/* EV_INIT_DONE: first valid measurement (EEPROM ya leida en task_system_init) */
			task_sensor_first = false;
			put_event_task_system(EV_SYS_INIT_DONE, 0.0f);
		}
		put_event_task_system(EV_SYS_SENSE_TICK, 0.0f);
	}
}

/********************** internal functions definition ************************/
static uint32_t task_sensor_adc_read(uint32_t channel)
{
	ADC_ChannelConfTypeDef s_config = {0};
	uint32_t value = 0;

	s_config.Channel = channel;
	s_config.Rank = ADC_REGULAR_RANK_1;
	s_config.SamplingTime = ADC_SAMPLETIME_239CYCLES_5;
	HAL_ADC_ConfigChannel(&hadc1, &s_config);

	HAL_ADC_Start(&hadc1);
	if (HAL_OK == HAL_ADC_PollForConversion(&hadc1, ADC_POLL_TIMEOUT))
	{
		value = HAL_ADC_GetValue(&hadc1);
	}
	HAL_ADC_Stop(&hadc1);

	return value;
}

/********************** end of file ******************************************/
