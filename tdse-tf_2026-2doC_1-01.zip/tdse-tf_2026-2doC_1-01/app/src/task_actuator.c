/*
 * Copyright (c) 2026 Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira
 *           (basado en el template TdSE de Juan Manuel Cruz <jcruz@fi.uba.ar>)
 */

/********************** inclusions *******************************************/
/* Project includes */
#include "main.h"

/* Demo includes */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes */
#include "board.h"
#include "app.h"
#include "task_actuator_attribute.h"
#include "task_actuator_interface.h"

/********************** macros and definitions *******************************/
#define DEL_LED_MIN		0ul
#define DEL_LED_MAX		500ul		/* [ms] semiperiodo de parpadeo (DEL_LED_MAX del statechart) */

#define ACTUATOR_CFG_QTY	(sizeof(task_actuator_cfg_list)/sizeof(task_actuator_cfg_t))
#define ACTUATOR_DTA_QTY	ACTUATOR_CFG_QTY

/********************** internal data declaration ****************************/
const task_actuator_cfg_t task_actuator_cfg_list[] = {
	{ID_LED_R,	LED_R_PORT,		LED_R_PIN,	LED_RGB_ON,	LED_RGB_OFF,	DEL_LED_MAX},
	{ID_LED_G,	LED_G_PORT,		LED_G_PIN,	LED_RGB_ON,	LED_RGB_OFF,	DEL_LED_MAX},
	{ID_LED_B,	LED_B_PORT,		LED_B_PIN,	LED_RGB_ON,	LED_RGB_OFF,	DEL_LED_MAX},
	{ID_RELAY,	RELAY_PORT,		RELAY_PIN,	RELAY_ON,	RELAY_OFF,		DEL_LED_MAX},
	{ID_BUZZER,	BUZZER_PORT,	BUZZER_PIN,	BUZZER_ON,	BUZZER_OFF,		DEL_LED_MAX},
	{ID_LED_HB,	LED_A_PORT,		LED_A_PIN,	LED_A_ON,	LED_A_OFF,		DEL_LED_MAX}
};

task_actuator_dta_t task_actuator_dta_list[ACTUATOR_DTA_QTY];

/********************** internal functions declaration ***********************/
void task_actuator_statechart(uint32_t index);

static void led_turn_on(uint32_t index);
static void led_turn_off(uint32_t index);
static void toggle_led(uint32_t index);

/********************** internal data definition *****************************/
const char *p_task_actuator 		= "Task Actuator (Actuator Statechart)";
const char *p_task_actuator_ 		= "Non-Blocking Code";
const char *p_task_actuator__ 		= "(Update by Time Code, period = 1mS)";

/********************** external data declaration ****************************/

/********************** external functions definition ************************/
void task_actuator_init(void *parameters)
{
	uint32_t index;
	task_actuator_dta_t *p_task_actuator_dta;
	task_actuator_st_t state;
	task_actuator_ev_t event;
	bool b_event;

	/* Print out: Task Initialized */
	LOGGER_INFO(" ");
	LOGGER_INFO("  %s is running - Tick [mS] = %lu", GET_NAME(task_actuator_init), HAL_GetTick());
	LOGGER_INFO("   %s is a %s", GET_NAME(task_actuator), p_task_actuator);
	LOGGER_INFO("   %s is a %s", GET_NAME(task_actuator), p_task_actuator_);
	LOGGER_INFO("   %s is a %s", GET_NAME(task_actuator), p_task_actuator__);

	for (index = 0; ACTUATOR_DTA_QTY > index; index++)
	{
		/* Update Task Actuator Data Pointer */
		p_task_actuator_dta = &task_actuator_dta_list[index];

		/* Init & Print out: Index & Task execution FSM (Entry -> ST_LED_OFF) */
		state = ST_LED_OFF;
		p_task_actuator_dta->state = state;

		event = EV_ACT_LED_OFF;
		p_task_actuator_dta->event = event;

		b_event = false;
		p_task_actuator_dta->flag = b_event;

		p_task_actuator_dta->tick = DEL_LED_MIN;

		LOGGER_INFO(" ");
		LOGGER_INFO("   %s = %lu   %s = %lu   %s = %lu   %s = %s",
					 GET_NAME(index), index,
					 GET_NAME(state), (uint32_t)state,
					 GET_NAME(event), (uint32_t)event,
					 GET_NAME(b_event), (b_event ? "true" : "false"));

		led_turn_off(index);
	}
}

void task_actuator_update(void *parameters)
{
	uint32_t index;

	for (index = 0; ACTUATOR_DTA_QTY > index; index++)
	{
		/* Run Task Statechart */
		task_actuator_statechart(index);
	}
}

void task_actuator_statechart(uint32_t index)
{
	const task_actuator_cfg_t *p_task_actuator_cfg;
	task_actuator_dta_t *p_task_actuator_dta;

	/* Update Task Actuator Configuration & Data Pointer */
	p_task_actuator_cfg = &task_actuator_cfg_list[index];
	p_task_actuator_dta = &task_actuator_dta_list[index];

	switch (p_task_actuator_dta->state)
	{
		case ST_LED_OFF:

			/* EV_ACT_LED_ON / led_turn_on() */
			if ((true == p_task_actuator_dta->flag) && (EV_ACT_LED_ON == p_task_actuator_dta->event))
			{
				p_task_actuator_dta->flag = false;
				led_turn_on(index);
				p_task_actuator_dta->state = ST_LED_ON;
			}
			/* EV_ACT_LED_BLINK / tick = DEL_LED_MAX; led_turn_on() */
			else if ((true == p_task_actuator_dta->flag) && (EV_ACT_LED_BLINK == p_task_actuator_dta->event))
			{
				p_task_actuator_dta->flag = false;
				p_task_actuator_dta->tick = p_task_actuator_cfg->tick_max;
				led_turn_on(index);
				p_task_actuator_dta->state = ST_LED_BLINK;
			}
			/* EV_ACT_LED_OFF / led_turn_off() (self-transition) */
			else if ((true == p_task_actuator_dta->flag) && (EV_ACT_LED_OFF == p_task_actuator_dta->event))
			{
				p_task_actuator_dta->flag = false;
				led_turn_off(index);
			}

			break;

		case ST_LED_ON:

			/* EV_ACT_LED_OFF / led_turn_off() */
			if ((true == p_task_actuator_dta->flag) && (EV_ACT_LED_OFF == p_task_actuator_dta->event))
			{
				p_task_actuator_dta->flag = false;
				led_turn_off(index);
				p_task_actuator_dta->state = ST_LED_OFF;
			}
			/* EV_ACT_LED_BLINK / tick = DEL_LED_MAX; led_turn_off() */
			else if ((true == p_task_actuator_dta->flag) && (EV_ACT_LED_BLINK == p_task_actuator_dta->event))
			{
				p_task_actuator_dta->flag = false;
				p_task_actuator_dta->tick = p_task_actuator_cfg->tick_max;
				led_turn_off(index);
				p_task_actuator_dta->state = ST_LED_BLINK;
			}
			/* EV_ACT_LED_ON / led_turn_on() (self-transition) */
			else if ((true == p_task_actuator_dta->flag) && (EV_ACT_LED_ON == p_task_actuator_dta->event))
			{
				p_task_actuator_dta->flag = false;
				led_turn_on(index);
			}

			break;

		case ST_LED_BLINK:

			/* EV_ACT_LED_OFF / led_turn_off() */
			if ((true == p_task_actuator_dta->flag) && (EV_ACT_LED_OFF == p_task_actuator_dta->event))
			{
				p_task_actuator_dta->flag = false;
				led_turn_off(index);
				p_task_actuator_dta->state = ST_LED_OFF;
			}
			/* EV_ACT_LED_ON / led_turn_on() */
			else if ((true == p_task_actuator_dta->flag) && (EV_ACT_LED_ON == p_task_actuator_dta->event))
			{
				p_task_actuator_dta->flag = false;
				led_turn_on(index);
				p_task_actuator_dta->state = ST_LED_ON;
			}
			/* Each 1 ms tick acts as the periodic EV_ACT_LED_BLINK of the statechart:
			 * [tick > 0]  / tick = tick - 1
			 * [tick == 0] / tick = DEL_LED_MAX; toggle_led()                         */
			else
			{
				p_task_actuator_dta->flag = false;

				if (DEL_LED_MIN < p_task_actuator_dta->tick)
				{
					p_task_actuator_dta->tick--;
				}
				else
				{
					p_task_actuator_dta->tick = p_task_actuator_cfg->tick_max;
					toggle_led(index);
				}
			}

			break;

		default:

			p_task_actuator_dta->tick  = DEL_LED_MIN;
			p_task_actuator_dta->state = ST_LED_OFF;
			p_task_actuator_dta->event = EV_ACT_LED_OFF;
			p_task_actuator_dta->flag  = false;
			led_turn_off(index);

			break;
	}
}

/********************** internal functions definition ************************/
/* Driver operations of the actuator statechart (GPIO) */
static void led_turn_on(uint32_t index)
{
	const task_actuator_cfg_t *p_cfg = &task_actuator_cfg_list[index];

	HAL_GPIO_WritePin(p_cfg->gpio_port, p_cfg->pin, p_cfg->led_on);
	task_actuator_dta_list[index].output = true;
}

static void led_turn_off(uint32_t index)
{
	const task_actuator_cfg_t *p_cfg = &task_actuator_cfg_list[index];

	HAL_GPIO_WritePin(p_cfg->gpio_port, p_cfg->pin, p_cfg->led_off);
	task_actuator_dta_list[index].output = false;
}

static void toggle_led(uint32_t index)
{
	if (true == task_actuator_dta_list[index].output)
		led_turn_off(index);
	else
		led_turn_on(index);
}

/********************** end of file ******************************************/
