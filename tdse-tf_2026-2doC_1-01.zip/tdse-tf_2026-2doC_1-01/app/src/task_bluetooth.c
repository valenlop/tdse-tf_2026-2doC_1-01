/*
 * Copyright (c) 2026 Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira
 *           (basado en el template TdSE de Juan Manuel Cruz <jcruz@fi.uba.ar>)
 */

/********************** inclusions *******************************************/
/* Project includes */
#include "main.h"

/* Demo includes */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes */
#include "board.h"
#include "app.h"
#include "ble_uart.h"
#include "task_system_interface.h"
#include "task_bluetooth_attribute.h"
#include "task_bluetooth_interface.h"

/********************** macros and definitions *******************************/
#define DEL_BLE_MIN			0ul
#define DEL_BLE_TELEMETRY	1000ul		/* [ms] every 1 s / sendTelemetry() (RF-06)        */
#define DEL_BLE_LINK		1000ul		/* [ms] antirrebote del pin STATE del HM-10        */
#define BLE_TX_MSG_MAX		64ul

/********************** internal data declaration ****************************/
task_bluetooth_dta_t task_bluetooth_dta;

/********************** internal functions declaration ***********************/
void task_bluetooth_statechart(void);

static void task_bluetooth_link_poll(void);
static void task_bluetooth_rx_poll(void);
static void task_bluetooth_enter_conectado(void);

/* Operations of the bluetooth statechart */
static bluetooth_cmd_t parseCommand(void);
static float getParsedSetpoint(void);
static void sendTelemetry(void);
static void sendAck(void);
static void sendNack(void);
static void sendAlert(void);

static bool parse_tenths(const char *p_str, int32_t *p_tenths);
static void fmt_temp(char *p_out, uint32_t size, float t);

/********************** internal data definition *****************************/
const char *p_task_bluetooth 	= "Task Bluetooth (Bluetooth Statechart)";
const char *p_task_bluetooth_ 	= "Non-Blocking Code";
const char *p_task_bluetooth__ 	= "(Update by Time Code, period = 1mS)";

static const char *p_ble_mode_name[] = {"INIT", "NORMAL", "HEATING", "SETUP", "ALARMA"};

/********************** external data declaration ****************************/

/********************** external functions definition ************************/
void task_bluetooth_init(void *parameters)
{
	task_bluetooth_dta_t *p_task_bluetooth_dta;

	/* Print out: Task Initialized */
	LOGGER_INFO(" ");
	LOGGER_INFO("  %s is running - Tick [mS] = %lu", GET_NAME(task_bluetooth_init), HAL_GetTick());
	LOGGER_INFO("   %s is a %s", GET_NAME(task_bluetooth), p_task_bluetooth);
	LOGGER_INFO("   %s is a %s", GET_NAME(task_bluetooth), p_task_bluetooth_);
	LOGGER_INFO("   %s is a %s", GET_NAME(task_bluetooth), p_task_bluetooth__);

	init_event_task_bluetooth();
	ble_uart_init();

	/* Update Task Bluetooth Data Pointer */
	p_task_bluetooth_dta = &task_bluetooth_dta;

	p_task_bluetooth_dta->tick            = DEL_BLE_MIN;
	p_task_bluetooth_dta->event           = EV_BLE_LINK_DOWN;
	p_task_bluetooth_dta->flag            = false;
	p_task_bluetooth_dta->cmd             = CMD_NONE;
	p_task_bluetooth_dta->parsed_setpoint = 0.0f;
	p_task_bluetooth_dta->line[0]         = '\0';
	p_task_bluetooth_dta->rx_len          = 0;
	p_task_bluetooth_dta->link            = false;
	p_task_bluetooth_dta->link_tick       = DEL_BLE_MIN;

	/* Initial transition: Entry -> DESCONECTADO */
	p_task_bluetooth_dta->state = ST_BLE_DESCONECTADO;

#if (0 == BLE_STATE_PIN_USED)
	/* STATE pin not wired: assume the link is always up */
	p_task_bluetooth_dta->link = true;
	put_event_task_bluetooth(EV_BLE_LINK_UP);
#endif
}

void task_bluetooth_update(void *parameters)
{
	/* Event generators: HM-10 STATE pin and UART RX */
	task_bluetooth_link_poll();
	task_bluetooth_rx_poll();

	/* Run Task Statechart */
	task_bluetooth_statechart();
}

void task_bluetooth_statechart(void)
{
	task_bluetooth_dta_t *p_task_bluetooth_dta;

	/* Update Task Bluetooth Data Pointer */
	p_task_bluetooth_dta = &task_bluetooth_dta;

	if (true == any_event_task_bluetooth())
	{
		p_task_bluetooth_dta->flag = true;
		p_task_bluetooth_dta->event = get_event_task_bluetooth();
	}

	switch (p_task_bluetooth_dta->state)
	{
		case ST_BLE_DESCONECTADO:

			/* linkUp -> CONECTADO */
			if ((true == p_task_bluetooth_dta->flag) && (EV_BLE_LINK_UP == p_task_bluetooth_dta->event))
			{
				p_task_bluetooth_dta->flag = false;
				task_bluetooth_enter_conectado();
			}

			break;

		case ST_BLE_ACTIVO:

			/* CONECTADO: linkDown -> DESCONECTADO */
			if ((true == p_task_bluetooth_dta->flag) && (EV_BLE_LINK_DOWN == p_task_bluetooth_dta->event))
			{
				p_task_bluetooth_dta->flag = false;
				p_task_bluetooth_dta->state = ST_BLE_DESCONECTADO;
				break;
			}

			/* CONECTADO: every 1 s / sendTelemetry() */
			if (DEL_BLE_MIN < p_task_bluetooth_dta->tick)
			{
				p_task_bluetooth_dta->tick--;
			}

			if (DEL_BLE_MIN == p_task_bluetooth_dta->tick)
			{
				p_task_bluetooth_dta->tick = DEL_BLE_TELEMETRY;
				sendTelemetry();
			}

			/* CONECTADO: alertaSistema / sendAlert() */
			if ((true == p_task_bluetooth_dta->flag) && (EV_BLE_ALERTA_SISTEMA == p_task_bluetooth_dta->event))
			{
				p_task_bluetooth_dta->flag = false;
				sendAlert();
			}
			/* ACTIVO: lineReceived / cmd = parseCommand() -> CHOICE */
			else if ((true == p_task_bluetooth_dta->flag) && (EV_BLE_LINE_RECEIVED == p_task_bluetooth_dta->event))
			{
				p_task_bluetooth_dta->flag = false;
				p_task_bluetooth_dta->cmd = parseCommand();

				/* CHOICE */
				if (CMD_SET_T == p_task_bluetooth_dta->cmd)
				{
					/* [cmd == CMD_SET_T] / raise EV_REQ_SET_PARAM : getParsedSetpoint(); sendAck() */
					put_event_task_system(EV_SYS_REQ_SET_PARAM, getParsedSetpoint());
					sendAck();
				}
				else if (CMD_MODE_SETUP == p_task_bluetooth_dta->cmd)
				{
					/* [cmd == CMD_MODE_SETUP] / raise EV_REQ_SETUP; sendAck() */
					put_event_task_system(EV_SYS_REQ_SETUP, 0.0f);
					sendAck();
				}
				else
				{
					/* [cmd != CMD_SET_T && cmd != CMD_MODE_SETUP] / sendNack() */
					sendNack();
				}
				/* -> ACTIVO */
			}

			break;

		default:

			p_task_bluetooth_dta->flag  = false;
			p_task_bluetooth_dta->state = ST_BLE_DESCONECTADO;

			break;
	}

	/* A received line is consumed whatever the state (frees the line buffer) */
	if (EV_BLE_LINE_RECEIVED == p_task_bluetooth_dta->event)
	{
		p_task_bluetooth_dta->line[0] = '\0';
	}

	p_task_bluetooth_dta->flag = false;
}

/********************** internal functions definition ************************/
static void task_bluetooth_enter_conectado(void)
{
	/* CONECTADO entry (every 1 s starts) + region activo: Entry -> ACTIVO */
	task_bluetooth_dta.tick = DEL_BLE_TELEMETRY;
	task_bluetooth_dta.state = ST_BLE_ACTIVO;
}

/* linkUp / linkDown generated from the HM-10 STATE pin (debounced) */
static void task_bluetooth_link_poll(void)
{
#if (1 == BLE_STATE_PIN_USED)
	task_bluetooth_dta_t *p_task_bluetooth_dta = &task_bluetooth_dta;
	bool pin_link = (BLE_STATE_LINK == HAL_GPIO_ReadPin(BLE_STATE_PORT, BLE_STATE_PIN));

	if (pin_link != p_task_bluetooth_dta->link)
	{
		p_task_bluetooth_dta->link_tick++;

		if (DEL_BLE_LINK <= p_task_bluetooth_dta->link_tick)
		{
			p_task_bluetooth_dta->link = pin_link;
			p_task_bluetooth_dta->link_tick = DEL_BLE_MIN;
			put_event_task_bluetooth(pin_link ? EV_BLE_LINK_UP : EV_BLE_LINK_DOWN);
		}
	}
	else
	{
		p_task_bluetooth_dta->link_tick = DEL_BLE_MIN;
	}
#endif
}

/* lineReceived generated when '\r' or '\n' arrives (non-blocking) */
static void task_bluetooth_rx_poll(void)
{
	task_bluetooth_dta_t *p_task_bluetooth_dta = &task_bluetooth_dta;
	uint8_t byte;

	/* Only one line pending at a time: the rest waits in the UART ring buffer */
	while (('\0' == p_task_bluetooth_dta->line[0]) && (true == ble_uart_read_byte(&byte)))
	{
		if (('\r' == byte) || ('\n' == byte))
		{
			if (0 < p_task_bluetooth_dta->rx_len)
			{
				p_task_bluetooth_dta->rx_line[p_task_bluetooth_dta->rx_len] = '\0';
				memcpy(p_task_bluetooth_dta->line, p_task_bluetooth_dta->rx_line, p_task_bluetooth_dta->rx_len + 1);
				p_task_bluetooth_dta->rx_len = 0;
				put_event_task_bluetooth(EV_BLE_LINE_RECEIVED);
			}
		}
		else if ((BLE_LINE_MAX - 1) > p_task_bluetooth_dta->rx_len)
		{
			/* Upper case, so commands are case insensitive */
			if (('a' <= byte) && ('z' >= byte))
				byte = (uint8_t)(byte - 'a' + 'A');

			p_task_bluetooth_dta->rx_line[p_task_bluetooth_dta->rx_len++] = (char)byte;
		}
		else
		{
			/* Line too long: discard it */
			p_task_bluetooth_dta->rx_len = 0;
		}
	}
}

/* operation parseCommand() : integer
 *  "SET_T=27.5" -> CMD_SET_T (valid range T_SET_MIN..T_SET_MAX)
 *  "MODE=SETUP" -> CMD_MODE_SETUP
 *  otherwise    -> CMD_NONE (=> NACK: INVALID_CMD)                          */
static bluetooth_cmd_t parseCommand(void)
{
	task_bluetooth_dta_t *p_task_bluetooth_dta = &task_bluetooth_dta;
	const char *p_line = p_task_bluetooth_dta->line;
	int32_t tenths;
	float value;

	if (0 == strncmp(p_line, "SET_T=", 6))
	{
		if (true == parse_tenths(&p_line[6], &tenths))
		{
			value = (float)tenths / 10.0f;

			if ((value >= SYS_T_SET_MIN) && (value <= SYS_T_SET_MAX))
			{
				p_task_bluetooth_dta->parsed_setpoint = value;
				return CMD_SET_T;
			}
		}
		return CMD_NONE;
	}

	if (0 == strcmp(p_line, "MODE=SETUP"))
	{
		return CMD_MODE_SETUP;
	}

	return CMD_NONE;
}

/* operation getParsedSetpoint() : real */
static float getParsedSetpoint(void)
{
	return task_bluetooth_dta.parsed_setpoint;
}

/* operation sendTelemetry(): "T=23.5;L=512;TS=25.0;R=0;M=NORMAL" */
static void sendTelemetry(void)
{
	char msg[BLE_TX_MSG_MAX];
	char t_str[16];
	char ts_str[16];
	system_mode_t modo = get_mode_task_system();

	fmt_temp(t_str, sizeof(t_str), get_t_medida_task_system());
	fmt_temp(ts_str, sizeof(ts_str), get_t_set_task_system());

	snprintf(msg, sizeof(msg), "T=%s;L=%lu;TS=%s;R=%d;M=%s\r\n",
			 t_str,
			 (unsigned long)get_ldr_val_task_system(),
			 ts_str,
			 (get_relay_task_system() ? 1 : 0),
			 p_ble_mode_name[modo]);

	ble_uart_write(msg);
}

/* operation sendAck() */
static void sendAck(void)
{
	ble_uart_write("ACK\r\n");
}

/* operation sendNack() (UC-04 a) */
static void sendNack(void)
{
	ble_uart_write("NACK: INVALID_CMD\r\n");
}

/* operation sendAlert() (UC-03 paso 6) */
static void sendAlert(void)
{
	if (CAUSA_TEMP == get_alarm_cause_task_system())
		ble_uart_write("ALERTA: ALT TEMP!\r\n");
	else
		ble_uart_write("ALERTA: TAPA ABIERTA!\r\n");
}

/* Parse "[-]d[.d]" into tenths (no float library needed) */
static bool parse_tenths(const char *p_str, int32_t *p_tenths)
{
	int32_t integer = 0;
	int32_t decimal = 0;
	bool negative = false;
	bool digits = false;

	if ('-' == *p_str)
	{
		negative = true;
		p_str++;
	}

	while (('0' <= *p_str) && ('9' >= *p_str))
	{
		integer = (integer * 10) + (*p_str - '0');
		digits = true;
		p_str++;

		if (1000 < integer)
			return false;
	}

	if ('.' == *p_str)
	{
		p_str++;

		if (('0' <= *p_str) && ('9' >= *p_str))
		{
			decimal = *p_str - '0';
			p_str++;
		}

		/* Extra decimals are ignored (truncated) */
		while (('0' <= *p_str) && ('9' >= *p_str))
			p_str++;
	}

	if ((false == digits) || ('\0' != *p_str))
		return false;

	*p_tenths = (integer * 10) + decimal;
	if (true == negative)
		*p_tenths = -(*p_tenths);

	return true;
}

static void fmt_temp(char *p_out, uint32_t size, float t)
{
	int32_t tenths = (int32_t)((t >= 0.0f) ? (t * 10.0f + 0.5f) : (t * 10.0f - 0.5f));
	const char *p_sign = (tenths < 0) ? "-" : "";

	if (tenths < 0)
		tenths = -tenths;

	snprintf(p_out, size, "%s%ld.%ld", p_sign, (long)(tenths / 10), (long)(tenths % 10));
}

/********************** end of file ******************************************/
