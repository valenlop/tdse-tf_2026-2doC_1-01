/*
 * Copyright (c) 2026 Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira
 *           (basado en el template TdSE de Juan Manuel Cruz <jcruz@fi.uba.ar>)
 */

/********************** inclusions *******************************************/
/* Project includes */
#include "main.h"

/* Demo includes */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes */
#include "board.h"
#include "app.h"
#include "lcd.h"

/********************** macros and definitions *******************************/
/* PCF8574 -> HD44780: P0 = RS, P1 = RW, P2 = EN, P3 = Backlight, P4..P7 = D4..D7 */
#define LCD_RS				(0x01)
#define LCD_RW				(0x02)
#define LCD_EN				(0x04)
#define LCD_BL				(0x08)

#define LCD_I2C_TIMEOUT		(2ul)		/* [ms] */

/********************** internal data declaration ****************************/

/********************** internal functions declaration ***********************/
static bool lcd_write_nibble(uint8_t nibble, uint8_t rs);
static bool lcd_write_byte(uint8_t byte, uint8_t rs);

/********************** internal data definition *****************************/

/********************** external data declaration ****************************/

/********************** external functions definition ************************/
bool lcd_init(void)
{
	bool ok = true;

	/* HD44780 power-on: > 40 ms after Vcc */
	HAL_Delay(50);

	/* 4-bit initialization by instruction */
	ok &= lcd_write_nibble(0x30, 0);
	HAL_Delay(5);
	ok &= lcd_write_nibble(0x30, 0);
	HAL_Delay(1);
	ok &= lcd_write_nibble(0x30, 0);
	HAL_Delay(1);
	ok &= lcd_write_nibble(0x20, 0);
	HAL_Delay(1);

	ok &= lcd_write_cmd(0x28);			/* Function set: 4 bits, 2 lines, 5x8 */
	ok &= lcd_write_cmd(0x08);			/* Display off                        */
	ok &= lcd_write_cmd(LCD_CMD_CLEAR);	/* Clear display                      */
	HAL_Delay(2);
	ok &= lcd_write_cmd(0x06);			/* Entry mode: increment, no shift    */
	ok &= lcd_write_cmd(0x0C);			/* Display on, cursor off, blink off  */

	return ok;
}

bool lcd_write_cmd(uint8_t cmd)
{
	return lcd_write_byte(cmd, 0);
}

bool lcd_write_data(uint8_t data)
{
	return lcd_write_byte(data, LCD_RS);
}

/********************** internal functions definition ************************/
static bool lcd_write_nibble(uint8_t nibble, uint8_t rs)
{
	uint8_t buf[2];

	buf[0] = (nibble & 0xF0) | LCD_BL | LCD_EN | rs;
	buf[1] = (nibble & 0xF0) | LCD_BL | rs;

	return (HAL_OK == HAL_I2C_Master_Transmit(&hi2c1, LCD_I2C_ADDR, buf, sizeof(buf), LCD_I2C_TIMEOUT));
}

/* One byte = two nibbles, each one latched with an EN pulse: 4 bytes over I2C */
static bool lcd_write_byte(uint8_t byte, uint8_t rs)
{
	uint8_t buf[4];

	buf[0] = (byte & 0xF0) | LCD_BL | LCD_EN | rs;
	buf[1] = (byte & 0xF0) | LCD_BL | rs;
	buf[2] = ((byte << 4) & 0xF0) | LCD_BL | LCD_EN | rs;
	buf[3] = ((byte << 4) & 0xF0) | LCD_BL | rs;

	return (HAL_OK == HAL_I2C_Master_Transmit(&hi2c1, LCD_I2C_ADDR, buf, sizeof(buf), LCD_I2C_TIMEOUT));
}

/********************** end of file ******************************************/
