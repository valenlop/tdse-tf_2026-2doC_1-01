/*
 * Copyright (c) 2026 Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira
 *           (basado en el template TdSE de Juan Manuel Cruz <jcruz@fi.uba.ar>)
 */

/********************** inclusions *******************************************/
/* Project includes */
#include "main.h"

/* Demo includes */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes */
#include "board.h"
#include "app.h"
#include "task_system_interface.h"
#include "task_display_interface.h"
#include "task_signaling_interface.h"
#include "task_ui_attribute.h"
#include "task_ui_interface.h"

/********************** macros and definitions *******************************/
#define DEL_UI_MIN			0ul
#define DEL_UI_REFRESH		500ul		/* [ms] every 500 ms / raise EV_UI_REFRESH */
#define DEL_UI_EDIT			10000ul		/* [ms] after 10 s (UC-02 a)               */

#define T_STEP				(0.5f)
#define T_SET_MIN			SYS_T_SET_MIN
#define T_SET_MAX			SYS_T_SET_MAX

/********************** internal data declaration ****************************/
task_ui_dta_t task_ui_dta;

/********************** internal functions declaration ***********************/
void task_ui_statechart(void);

static void task_ui_enter(task_ui_st_t state);
static void task_ui_refresh_every_500ms(void);

/********************** internal data definition *****************************/
const char *p_task_ui 		= "Task UI (UI Statechart)";
const char *p_task_ui_ 		= "Non-Blocking Code";
const char *p_task_ui__ 	= "(Update by Time Code, period = 1mS)";

/********************** external data declaration ****************************/

/********************** external functions definition ************************/
void task_ui_init(void *parameters)
{
	task_ui_dta_t *p_task_ui_dta;

	/* Print out: Task Initialized */
	LOGGER_INFO(" ");
	LOGGER_INFO("  %s is running - Tick [mS] = %lu", GET_NAME(task_ui_init), HAL_GetTick());
	LOGGER_INFO("   %s is a %s", GET_NAME(task_ui), p_task_ui);
	LOGGER_INFO("   %s is a %s", GET_NAME(task_ui), p_task_ui_);
	LOGGER_INFO("   %s is a %s", GET_NAME(task_ui), p_task_ui__);

	init_event_task_ui();

	/* Update Task UI Data Pointer */
	p_task_ui_dta = &task_ui_dta;

	p_task_ui_dta->tick      = DEL_UI_MIN;
	p_task_ui_dta->tick_edit = DEL_UI_MIN;
	p_task_ui_dta->event     = EV_UI_MODE_CHANGED;
	p_task_ui_dta->value     = 0;
	p_task_ui_dta->flag      = false;
	p_task_ui_dta->t_set     = SYS_T_SET_MIN;
	p_task_ui_dta->t_edit    = SYS_T_SET_MIN;

	/* Initial transition: Entry -> ST_UI_INIT */
	task_ui_enter(ST_UI_INIT);

	LOGGER_INFO(" ");
	LOGGER_INFO("   %s = %lu   %s = %lu   %s = %s",
				GET_NAME(state), (uint32_t)p_task_ui_dta->state,
				GET_NAME(event), (uint32_t)p_task_ui_dta->event,
				GET_NAME(b_event), (p_task_ui_dta->flag ? "true" : "false"));
}

void task_ui_update(void *parameters)
{
	/* Run Task Statechart */
	task_ui_statechart();
}

void task_ui_statechart(void)
{
	task_ui_dta_t *p_task_ui_dta;
	bool b_mode_changed;

	/* Update Task UI Data Pointer */
	p_task_ui_dta = &task_ui_dta;

	if (true == any_event_task_ui())
	{
		p_task_ui_dta->flag = true;
		p_task_ui_dta->event = get_event_task_ui(&p_task_ui_dta->value);
	}

	b_mode_changed = (true == p_task_ui_dta->flag) && (EV_UI_MODE_CHANGED == p_task_ui_dta->event);

	switch (p_task_ui_dta->state)
	{
		case ST_UI_INIT:

			/* EV_MODE_CHANGED [valueof(EV_MODE_CHANGED) == MODO_NORMAL] -> ST_UI_MONITOR */
			if (b_mode_changed && (MODO_NORMAL == p_task_ui_dta->value))
			{
				p_task_ui_dta->flag = false;
				task_ui_enter(ST_UI_NORMAL);
			}

			break;

		case ST_UI_NORMAL:
		case ST_UI_HEATING:

			/* ST_UI_MONITOR: every 500 ms / raise EV_UI_REFRESH */
			task_ui_refresh_every_500ms();

			/* ST_UI_MONITOR -> ST_UI_ALARMA */
			if (b_mode_changed && (MODO_ALARMA == p_task_ui_dta->value))
			{
				p_task_ui_dta->flag = false;
				task_ui_enter(ST_UI_ALARMA);
			}
			/* ST_UI_MONITOR -> ST_UI_SETUP */
			else if (b_mode_changed && (MODO_SETUP == p_task_ui_dta->value))
			{
				p_task_ui_dta->flag = false;
				task_ui_enter(ST_UI_EDIT);
			}
			/* ST_UI_NORMAL -> ST_UI_HEATING */
			else if (b_mode_changed && (MODO_HEATING == p_task_ui_dta->value)
					 && (ST_UI_NORMAL == p_task_ui_dta->state))
			{
				p_task_ui_dta->flag = false;
				task_ui_enter(ST_UI_HEATING);
			}
			/* ST_UI_HEATING -> ST_UI_NORMAL */
			else if (b_mode_changed && (MODO_NORMAL == p_task_ui_dta->value)
					 && (ST_UI_HEATING == p_task_ui_dta->state))
			{
				p_task_ui_dta->flag = false;
				task_ui_enter(ST_UI_NORMAL);
			}
			/* ST_UI_MONITOR: EV_KEY1_PRESSED / raise EV_REQ_SETUP */
			else if ((true == p_task_ui_dta->flag) && (EV_UI_KEY1_PRESSED == p_task_ui_dta->event))
			{
				p_task_ui_dta->flag = false;
				put_event_task_system(EV_SYS_REQ_SETUP, 0.0f);
			}

			break;

		case ST_UI_EDIT:

			/* after 10 s / raise EV_SETUP_TIMEOUT; raise EV_UI_MSG : MSG_TIMEOUT -> ST_UI_MONITOR */
			if (DEL_UI_MIN < p_task_ui_dta->tick_edit)
			{
				p_task_ui_dta->tick_edit--;
			}

			if (DEL_UI_MIN == p_task_ui_dta->tick_edit)
			{
				put_event_task_system(EV_SYS_SETUP_TIMEOUT, 0.0f);
				put_event_task_display(EV_DISP_MSG, (int32_t)MSG_TIMEOUT);
				task_ui_enter(ST_UI_NORMAL);
			}
			/* ST_UI_SETUP -> ST_UI_ALARMA */
			else if (b_mode_changed && (MODO_ALARMA == p_task_ui_dta->value))
			{
				p_task_ui_dta->flag = false;
				task_ui_enter(ST_UI_ALARMA);
			}
			/* ST_UI_SETUP -> ST_UI_MONITOR (MODO_NORMAL: guardado, cancelado o timeout) */
			else if (b_mode_changed && (MODO_NORMAL == p_task_ui_dta->value))
			{
				p_task_ui_dta->flag = false;
				task_ui_enter(ST_UI_NORMAL);
			}
			/* EV_KEY1_PRESSED [T_edit + T_STEP <= T_SET_MAX] / T_edit = T_edit + T_STEP */
			else if ((true == p_task_ui_dta->flag) && (EV_UI_KEY1_PRESSED == p_task_ui_dta->event))
			{
				p_task_ui_dta->flag = false;
				if ((p_task_ui_dta->t_edit + T_STEP) <= T_SET_MAX)
				{
					p_task_ui_dta->t_edit += T_STEP;
					task_ui_enter(ST_UI_EDIT);		/* self-transition: restarts "after 10 s" */
				}
			}
			/* EV_KEY2_PRESSED [T_edit - T_STEP >= T_SET_MIN] / T_edit = T_edit - T_STEP */
			else if ((true == p_task_ui_dta->flag) && (EV_UI_KEY2_PRESSED == p_task_ui_dta->event))
			{
				p_task_ui_dta->flag = false;
				if ((p_task_ui_dta->t_edit - T_STEP) >= T_SET_MIN)
				{
					p_task_ui_dta->t_edit -= T_STEP;
					task_ui_enter(ST_UI_EDIT);		/* self-transition: restarts "after 10 s" */
				}
			}
			/* EV_KEY3_PRESSED / raise EV_REQ_SAVE : T_edit  (ver REVISION.md) */
			else if ((true == p_task_ui_dta->flag) && (EV_UI_KEY3_PRESSED == p_task_ui_dta->event))
			{
				p_task_ui_dta->flag = false;
				put_event_task_system(EV_SYS_REQ_SAVE, p_task_ui_dta->t_edit);
			}
			/* ST_UI_SETUP: EV_KEY4_PRESSED / raise EV_REQ_NORMAL */
			else if ((true == p_task_ui_dta->flag) && (EV_UI_KEY4_PRESSED == p_task_ui_dta->event))
			{
				p_task_ui_dta->flag = false;
				put_event_task_system(EV_SYS_REQ_NORMAL, 0.0f);
			}

			break;

		case ST_UI_ALARMA:

			/* Refresh also in ALARMA to show the live temperature (ver REVISION.md) */
			task_ui_refresh_every_500ms();

			/* ST_UI_ALARMA -> ST_UI_NORMAL */
			if (b_mode_changed && (MODO_NORMAL == p_task_ui_dta->value))
			{
				p_task_ui_dta->flag = false;
				task_ui_enter(ST_UI_NORMAL);
			}
			/* EV_KEY1_PRESSED / raise EV_REQ_MUTE */
			else if ((true == p_task_ui_dta->flag) && (EV_UI_KEY1_PRESSED == p_task_ui_dta->event))
			{
				p_task_ui_dta->flag = false;
				put_event_task_signaling(EV_SIG_REQ_MUTE, 0);
			}
			/* EV_KEY2_PRESSED / raise EV_REQ_RESET */
			else if ((true == p_task_ui_dta->flag) && (EV_UI_KEY2_PRESSED == p_task_ui_dta->event))
			{
				p_task_ui_dta->flag = false;
				put_event_task_system(EV_SYS_REQ_RESET, 0.0f);
			}

			break;

		default:

			p_task_ui_dta->flag = false;
			task_ui_enter(ST_UI_INIT);

			break;
	}

	/* Events not handled in the current state are discarded */
	p_task_ui_dta->flag = false;
}

/********************** internal functions definition ************************/
/* Transition: update state and run the entry actions of the target state */
static void task_ui_enter(task_ui_st_t state)
{
	task_ui_dta_t *p_task_ui_dta = &task_ui_dta;
	task_ui_st_t state_prev = p_task_ui_dta->state;

	p_task_ui_dta->state = state;

	switch (state)
	{
		case ST_UI_INIT:
			put_event_task_display(EV_DISP_SCREEN, (int32_t)SCR_INIT);
			break;

		case ST_UI_NORMAL:
			p_task_ui_dta->tick = DEL_UI_REFRESH;
			put_event_task_display(EV_DISP_SCREEN, (int32_t)SCR_NORMAL);
			break;

		case ST_UI_HEATING:
			p_task_ui_dta->tick = DEL_UI_REFRESH;
			put_event_task_display(EV_DISP_SCREEN, (int32_t)SCR_HEATING);
			break;

		case ST_UI_EDIT:
			/* ST_UI_SETUP entry / T_edit = T_set (only when entering from outside ST_UI_SETUP) */
			if (ST_UI_EDIT != state_prev)
			{
				p_task_ui_dta->t_set  = get_t_set_task_system();
				p_task_ui_dta->t_edit = p_task_ui_dta->t_set;
			}
			p_task_ui_dta->tick_edit = DEL_UI_EDIT;
			put_event_task_display(EV_DISP_SCREEN, (int32_t)SCR_SETUP);
			break;

		case ST_UI_ALARMA:
			p_task_ui_dta->tick = DEL_UI_REFRESH;
			put_event_task_display(EV_DISP_SCREEN, (int32_t)SCR_ALARMA);
			break;

		default:
			break;
	}
}

/* every 500 ms / raise EV_UI_REFRESH */
static void task_ui_refresh_every_500ms(void)
{
	task_ui_dta_t *p_task_ui_dta = &task_ui_dta;

	if (DEL_UI_MIN < p_task_ui_dta->tick)
	{
		p_task_ui_dta->tick--;
	}

	if (DEL_UI_MIN == p_task_ui_dta->tick)
	{
		p_task_ui_dta->tick = DEL_UI_REFRESH;
		put_event_task_display(EV_DISP_REFRESH, 0);
	}
}

/********************** end of file ******************************************/
