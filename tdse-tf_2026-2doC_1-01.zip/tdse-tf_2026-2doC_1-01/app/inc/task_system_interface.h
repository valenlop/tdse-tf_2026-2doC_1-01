/*
 * Copyright (c) 2026 Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira
 *           (basado en el template TdSE de Juan Manuel Cruz <jcruz@fi.uba.ar>)
 */

#ifndef TASK_SYSTEM_INTERFACE_H_
#define TASK_SYSTEM_INTERFACE_H_

/********************** CPP guard ********************************************/
#ifdef __cplusplus
extern "C" {
#endif

/********************** inclusions *******************************************/
#include <stdint.h>
#include <stdbool.h>

/********************** macros ***********************************************/
/* Rango valido de T_set (T_SET_MIN / T_SET_MAX de task_ui, usado tambien por BLE) */
#define SYS_T_SET_MIN		(15.0f)
#define SYS_T_SET_MAX		(40.0f)

/********************** typedef **********************************************/
/* Events to excite Task System (statechart task_system) */
typedef enum task_system_ev {
	EV_SYS_INIT_DONE = 0,	/* EV_INIT_DONE      : primera medicion lista       */
	EV_SYS_SENSE_TICK,		/* EV_SENSE_TICK     : nueva medicion (T, L)        */
	EV_SYS_REQ_SETUP,		/* EV_REQ_SETUP      : Teclado o BLE                */
	EV_SYS_REQ_NORMAL,		/* EV_REQ_NORMAL     : cancelar SET_UP              */
	EV_SYS_REQ_SAVE,		/* EV_REQ_SAVE       : guardar T_edit (value)       */
	EV_SYS_SETUP_TIMEOUT,	/* EV_SETUP_TIMEOUT  : inactividad en SET_UP        */
	EV_SYS_REQ_SET_PARAM,	/* EV_REQ_SET_PARAM  : SET_T=xx por BLE (value)     */
	EV_SYS_REQ_RESET		/* EV_REQ_RESET      : reset de alarma              */
} task_system_ev_t;

/* Modo global difundido con EV_MODE_CHANGED (sincronizado con task_ui y task_signaling) */
typedef enum system_mode {
	MODO_INIT = 0,
	MODO_NORMAL,
	MODO_HEATING,
	MODO_SETUP,
	MODO_ALARMA
} system_mode_t;

/* Causa de la alarma */
typedef enum system_alarm_cause {
	CAUSA_NONE = 0,
	CAUSA_TEMP,
	CAUSA_TAPA
} system_alarm_cause_t;

/* Parametros guardados en EEPROM */
typedef enum system_param {
	PAR_TSET = 0,
	PAR_TMAX
} system_param_t;

/********************** external data declaration ****************************/

/********************** external functions declaration ***********************/
extern void init_event_task_system(void);
extern void put_event_task_system(task_system_ev_t event, float value);
extern task_system_ev_t get_event_task_system(float *p_value);
extern bool any_event_task_system(void);

/* Getters (lectura del estado de task_system desde otras tareas) */
extern system_mode_t get_mode_task_system(void);
extern float get_t_medida_task_system(void);
extern float get_t_set_task_system(void);
extern float get_t_max_task_system(void);
extern uint32_t get_ldr_val_task_system(void);
extern system_alarm_cause_t get_alarm_cause_task_system(void);
extern bool get_relay_task_system(void);

/********************** End of CPP guard *************************************/
#ifdef __cplusplus
}
#endif

#endif /* TASK_SYSTEM_INTERFACE_H_ */

/********************** end of file ******************************************/
