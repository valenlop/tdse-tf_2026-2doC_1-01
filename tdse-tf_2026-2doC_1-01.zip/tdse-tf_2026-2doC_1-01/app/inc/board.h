/*
 * Copyright (c) 2026 Juan Manuel Cruz <jcruz@fi.uba.ar>.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>
 */

#ifndef BOARD_H_
#define BOARD_H_

/********************** CPP guard ********************************************/
#ifdef __cplusplus
extern "C" {
#endif

/********************** inclusions *******************************************/
#include "main.h"
/********************** macros ***********************************************/
#define ZERO				(0)

#define NUCLEO_F103RC		(0)
#define NUCLEO_F303K8		(1)
#define NUCLEO_F401RE		(2)
#define NUCLEO_F446RE		(3)
#define NUCLEO_F413ZH		(4)
#define NUCLEO_F429ZI		(5)
#define NUCLEO_F439ZI		(6)
#define NUCLEO_F767ZI		(7)
#define STM32F407G_DISC1	(8)
#define STM32F429I_DISC1	(9)

#define BOARD (NUCLEO_F103RC)

/* STM32 Nucleo Boards - 32 Pins */
#if (BOARD == NUCLEO_F303K8)

#endif

/* STM32 Nucleo Boards - 64 Pins */
#if ((BOARD == NUCLEO_F103RC) || (BOARD == NUCLEO_F401RE) || (BOARD == NUCLEO_F446RE))

/* ---- Teclado de membrana 1x4 (comun a GND, entradas con pull-up) ---- */
#define KEY1_PIN		KEY1_Pin			/* PA8  - D7  */
#define KEY1_PORT		KEY1_GPIO_Port
#define KEY1_PRESSED	GPIO_PIN_RESET

#define KEY2_PIN		KEY2_Pin			/* PB10 - D6  */
#define KEY2_PORT		KEY2_GPIO_Port
#define KEY2_PRESSED	GPIO_PIN_RESET

#define KEY3_PIN		KEY3_Pin			/* PB5  - D4  */
#define KEY3_PORT		KEY3_GPIO_Port
#define KEY3_PRESSED	GPIO_PIN_RESET

#define KEY4_PIN		KEY4_Pin			/* PC0  - A5  */
#define KEY4_PORT		KEY4_GPIO_Port
#define KEY4_PRESSED	GPIO_PIN_RESET

/* ---- LED RGB (catodo comun: ON = nivel alto) ---- */
#define LED_R_PIN		LED_R_Pin			/* PA6  - D12 */
#define LED_R_PORT		LED_R_GPIO_Port
#define LED_G_PIN		LED_G_Pin			/* PA7  - D11 */
#define LED_G_PORT		LED_G_GPIO_Port
#define LED_B_PIN		LED_B_Pin			/* PB6  - D10 */
#define LED_B_PORT		LED_B_GPIO_Port
#define LED_RGB_ON		GPIO_PIN_SET		/* Anodo comun => GPIO_PIN_RESET */
#define LED_RGB_OFF		GPIO_PIN_RESET

/* ---- Rele de calefaccion ---- */
#define RELAY_PIN		RELAY_Pin			/* PB0  - A3  */
#define RELAY_PORT		RELAY_GPIO_Port
#define RELAY_ON		GPIO_PIN_SET		/* Modulos de rele activos en bajo => GPIO_PIN_RESET */
#define RELAY_OFF		GPIO_PIN_RESET

/* ---- Buzzer activo ---- */
#define BUZZER_PIN		BUZZER_Pin			/* PC7  - D9  */
#define BUZZER_PORT		BUZZER_GPIO_Port
#define BUZZER_ON		GPIO_PIN_SET
#define BUZZER_OFF		GPIO_PIN_RESET

/* ---- LED de la placa (LD2), usado como "heartbeat" ---- */
#define LED_A_PIN		LD2_Pin				/* PA5  - D13 */
#define LED_A_PORT		LD2_GPIO_Port
#define LED_A_ON		GPIO_PIN_SET
#define LED_A_OFF		GPIO_PIN_RESET

/* ---- HM-10 (USART1 PA9 TX - D8 / PA10 RX - D2, 9600 baud) ---- */
#define BLE_STATE_PIN	BLE_STATE_Pin		/* PC1  - A4  */
#define BLE_STATE_PORT	BLE_STATE_GPIO_Port
#define BLE_STATE_LINK	GPIO_PIN_SET
/* 1: usa el pin STATE del HM-10 para generar linkUp/linkDown.
 * 0: no se cablea STATE; se asume enlace siempre activo (linkUp al iniciar). */
#define BLE_STATE_PIN_USED	(0)

/* ---- Bus I2C1 (PB8 SCL - D15 / PB9 SDA - D14, 100 kHz) ---- */
#define LCD_I2C_ADDR		(0x27 << 1)		/* PCF8574 = 0x27, PCF8574A = 0x3F */
#define EEPROM_I2C_ADDR		(0x50 << 1)		/* 24C32/24C64/24LC256 (A2..A0 = 0) */
#define EEPROM_MEM_ADD_SIZE	I2C_MEMADD_SIZE_16BIT	/* 24C01..24C16 => I2C_MEMADD_SIZE_8BIT */

/* ---- ADC1 ---- */
#define LM35_ADC_CHANNEL	ADC_CHANNEL_0	/* PA0  - A0  */
#define LDR_ADC_CHANNEL		ADC_CHANNEL_1	/* PA1  - A1  */
#define ADC_VREF_MV			(3300ul)
#define ADC_FULL_SCALE		(4095ul)

#endif

/* STM32 Nucleo Boards - 144 Pins */
#if ((BOARD == NUCLEO_F413ZH) || (BOARD == NUCLEO_F429ZI) || (BOARD == NUCLEO_F439ZI) || (BOARD == NUCLEO_F767ZI))

#define BTN_A_PIN		USER_Btn_Pin
#define BTN_A_PORT		USER_Btn_GPIO_Port
#define BTN_A_PRESSED	GPIO_PIN_SET
#define BTN_A_HOVER		GPIO_PIN_RESET

#define LED_A_PIN		LD1_Pin
#define LED_A_PORT		LD1_GPIO_Port
#define LED_A_ON		GPIO_PIN_SET
#define LED_A_OFF		GPIO_PIN_RESET

#endif

/* STM32 Discovery Kits */
#if ((BOARD == STM32F407G_DISC1) || (BOARD == STM32F429I_DISC1))

#define BTN_A_PIN		B1_Pin
#define BTN_A_PORT		B1_GPIO_Port
#define BTN_A_PRESSED	GPIO_PIN_SET
#define BTN_A_HOVER		GPIO_PIN_RESET

#define LED_A_PIN		LD3_Pin
#define LED_A_PORT		LD3_GPIO_Port
#define LED_A_ON		GPIO_PIN_SET
#define LED_A_OFF		GPIO_PIN_RESET

#endif

/********************** typedef **********************************************/

/********************** external data declaration ****************************/
/* Handles generados por CubeMX en main.c */
extern ADC_HandleTypeDef	hadc1;
extern I2C_HandleTypeDef	hi2c1;
extern UART_HandleTypeDef	huart1;

/********************** external functions declaration ***********************/

/********************** End of CPP guard *************************************/
#ifdef __cplusplus
}
#endif

#endif /* BOARD_H_ */

/********************** end of file ******************************************/
