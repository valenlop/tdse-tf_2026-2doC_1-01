/*
 * Copyright (c) 2026 Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira
 *           (basado en el template TdSE de Juan Manuel Cruz <jcruz@fi.uba.ar>)
 */

#ifndef TASK_BUTTON_ATTRIBUTE_H_
#define TASK_BUTTON_ATTRIBUTE_H_

/********************** CPP guard ********************************************/
#ifdef __cplusplus
extern "C" {
#endif

/********************** inclusions *******************************************/
#include "task_ui_interface.h"

/********************** macros ***********************************************/

/********************** typedef **********************************************/
/* Events to excite Task Button */
typedef enum task_button_ev {EV_BTN_UP,
							 EV_BTN_DOWN} task_button_ev_t;

/* States of Task Button */
typedef enum task_button_st {ST_BTN_UP,
							 ST_BTN_FALLING,
							 ST_BTN_DOWN,
							 ST_BTN_RISING} task_button_st_t;

/* Identifier of Task Button (teclado 1x4) */
typedef enum task_button_id {ID_KEY1,
							 ID_KEY2,
							 ID_KEY3,
							 ID_KEY4} task_button_id_t;

typedef struct
{
	task_button_id_t	identifier;
	GPIO_TypeDef *		gpio_port;
	uint16_t			pin;
	GPIO_PinState		pressed;
	uint32_t			tick_max_down;		/* DEL_BTN_DOWN */
	uint32_t			tick_max_up;		/* DEL_BTN_UP   */
	task_ui_ev_t		signal_pressed;		/* EV_SYS_BTN_PRESSED  -> task_ui */
	task_ui_ev_t		signal_released;	/* EV_SYS_BTN_RELEASED -> task_ui */
} task_button_cfg_t;

typedef struct
{
	uint32_t			tick;
	task_button_st_t	state;
	task_button_ev_t	event;
} task_button_dta_t;

/********************** external data declaration ****************************/
extern task_button_dta_t task_button_dta_list[];

/********************** external functions declaration ***********************/

/********************** End of CPP guard *************************************/
#ifdef __cplusplus
}
#endif

#endif /* TASK_BUTTON_ATTRIBUTE_H_ */

/********************** end of file ******************************************/
