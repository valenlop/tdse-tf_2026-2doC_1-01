/*
 * Copyright (c) 2026 Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira
 *           (basado en el template TdSE de Juan Manuel Cruz <jcruz@fi.uba.ar>)
 */

#ifndef TASK_UI_ATTRIBUTE_H_
#define TASK_UI_ATTRIBUTE_H_

/********************** CPP guard ********************************************/
#ifdef __cplusplus
extern "C" {
#endif

/********************** inclusions *******************************************/
#include <stdint.h>
#include <stdbool.h>
#include "task_ui_interface.h"

/********************** macros ***********************************************/

/********************** typedef **********************************************/
/* States of Task UI (estados jerarquicos aplanados)
 *   ST_UI_INIT
 *   ST_UI_MONITOR { ST_UI_NORMAL, ST_UI_HEATING }
 *   ST_UI_SETUP   { ST_UI_EDIT }
 *   ST_UI_ALARMA                                                            */
typedef enum task_ui_st {
	ST_UI_INIT = 0,
	ST_UI_NORMAL,			/* ST_UI_MONITOR.ST_UI_NORMAL  */
	ST_UI_HEATING,			/* ST_UI_MONITOR.ST_UI_HEATING */
	ST_UI_EDIT,				/* ST_UI_SETUP.ST_UI_EDIT      */
	ST_UI_ALARMA
} task_ui_st_t;

typedef struct
{
	uint32_t		tick;			/* "every 500 ms" de ST_UI_MONITOR */
	uint32_t		tick_edit;		/* "after 10 s" de ST_UI_EDIT      */
	task_ui_st_t	state;
	task_ui_ev_t	event;
	int32_t			value;
	bool			flag;
	float			t_set;
	float			t_edit;
} task_ui_dta_t;

/********************** external data declaration ****************************/
extern task_ui_dta_t task_ui_dta;

/********************** external functions declaration ***********************/

/********************** End of CPP guard *************************************/
#ifdef __cplusplus
}
#endif

#endif /* TASK_UI_ATTRIBUTE_H_ */

/********************** end of file ******************************************/
