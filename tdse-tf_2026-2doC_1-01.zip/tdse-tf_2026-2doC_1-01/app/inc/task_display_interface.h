/*
 * Copyright (c) 2026 Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira
 *           (basado en el template TdSE de Juan Manuel Cruz <jcruz@fi.uba.ar>)
 */

#ifndef TASK_DISPLAY_INTERFACE_H_
#define TASK_DISPLAY_INTERFACE_H_

/********************** CPP guard ********************************************/
#ifdef __cplusplus
extern "C" {
#endif

/********************** inclusions *******************************************/
#include <stdint.h>
#include <stdbool.h>

/********************** macros ***********************************************/

/********************** typedef **********************************************/
/* Events to excite Task Display (statechart task_display + salidas de task_ui) */
typedef enum task_display_ev {
	EV_DISP_REFRESH = 0,	/* EV_UI_REFRESH                          */
	EV_DISP_SCREEN,			/* EV_UI_SCREEN : integer (display_scr_t) */
	EV_DISP_MSG				/* EV_UI_MSG    : integer (display_msg_t) */
} task_display_ev_t;

/* Pantallas del LCD (SCR_xxx de task_ui) */
typedef enum display_scr {
	SCR_INIT = 0,
	SCR_NORMAL,
	SCR_HEATING,
	SCR_SETUP,
	SCR_ALARMA
} display_scr_t;

/* Mensajes transitorios (MSG_xxx de task_ui) */
typedef enum display_msg {
	MSG_NONE = 0,
	MSG_TIMEOUT,			/* "TIEMPO AGOTADO" (UC-02 a) */
	MSG_EEPROM_ERR			/* "ERROR EEPROM"   (UC-02 b) */
} display_msg_t;

/********************** external data declaration ****************************/

/********************** external functions declaration ***********************/
extern void init_event_task_display(void);
extern void put_event_task_display(task_display_ev_t event, int32_t value);
extern task_display_ev_t get_event_task_display(int32_t *p_value);
extern bool any_event_task_display(void);

/********************** End of CPP guard *************************************/
#ifdef __cplusplus
}
#endif

#endif /* TASK_DISPLAY_INTERFACE_H_ */

/********************** end of file ******************************************/
