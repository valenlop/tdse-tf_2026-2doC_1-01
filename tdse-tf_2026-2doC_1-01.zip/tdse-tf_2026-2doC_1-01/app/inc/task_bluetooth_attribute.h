/*
 * Copyright (c) 2026 Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @author : Fernandez Luna, Felipe Mateo - Lopez Ruvira, Valentin - Yashnyk, Kira
 *           (basado en el template TdSE de Juan Manuel Cruz <jcruz@fi.uba.ar>)
 */

#ifndef TASK_BLUETOOTH_ATTRIBUTE_H_
#define TASK_BLUETOOTH_ATTRIBUTE_H_

/********************** CPP guard ********************************************/
#ifdef __cplusplus
extern "C" {
#endif

/********************** inclusions *******************************************/
#include <stdint.h>
#include <stdbool.h>
#include "task_bluetooth_interface.h"

/********************** macros ***********************************************/
#define BLE_LINE_MAX		(32ul)

/********************** typedef **********************************************/
/* States of Task Bluetooth
 *   ST_BLE_DESCONECTADO
 *   CONECTADO { ST_BLE_ACTIVO, CHOICE (pseudo-estado, se resuelve en la misma vuelta) } */
typedef enum task_bluetooth_st {
	ST_BLE_DESCONECTADO = 0,
	ST_BLE_ACTIVO				/* CONECTADO.activo.ACTIVO */
} task_bluetooth_st_t;

/* Comandos parseados (CMD_xxx del statechart) */
typedef enum bluetooth_cmd {
	CMD_NONE = 0,
	CMD_SET_T,			/* "SET_T=27.5" */
	CMD_MODE_SETUP		/* "MODE=SETUP" */
} bluetooth_cmd_t;

typedef struct
{
	uint32_t			tick;			/* "every 1 s" de CONECTADO */
	task_bluetooth_st_t	state;
	task_bluetooth_ev_t	event;
	bool				flag;
	bluetooth_cmd_t		cmd;
	float				parsed_setpoint;
	char				line[BLE_LINE_MAX];		/* linea recibida completa */
	char				rx_line[BLE_LINE_MAX];	/* linea en armado         */
	uint32_t			rx_len;
	bool				link;			/* ultimo estado del pin STATE */
	uint32_t			link_tick;		/* antirrebote del pin STATE   */
} task_bluetooth_dta_t;

/********************** external data declaration ****************************/
extern task_bluetooth_dta_t task_bluetooth_dta;

/********************** external functions declaration ***********************/

/********************** End of CPP guard *************************************/
#ifdef __cplusplus
}
#endif

#endif /* TASK_BLUETOOTH_ATTRIBUTE_H_ */

/********************** end of file ******************************************/
