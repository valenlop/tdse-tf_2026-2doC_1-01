Project: tdse-tf_2026-2doC_1-01 - Estacion de Control Ambiental

 Description:
 Bare Metal - Event-Triggered Systems (ETS)
 App - Estacion de Control Ambiental (LM35 + LDR + Rele + LED RGB + Buzzer +
       Teclado 1x4 + LCD 16x2 I2C + EEPROM I2C + Bluetooth HM-10)
 Project for STM32 Project (STM32CubeIDE Version: 1.19.0 & STM32Cube FW_F1 V1.8.6)

  SystemCoreClock     => 64MHz (15.625nS)
  SysTick Rate Hertz  => 1000 ticks per second (1mS)
  ADC clock           => PCLK2 / 6 = 10.67MHz

  app.c (app.h)
   Endless loops, which execute tasks with fixed computing time. This 
   sequential execution is only deviated from when an interrupt event occurs.
   Cyclic Executive (Update by Time Code, period = 1mS)
    
    app_it.c (app_it.h)
	 Utilities for "Callbacks" (SysTick, EXTI, UART HM-10)

    task_button.c (task_button.h, task_button_attribute.h)
     Non-Blocking Code (Update by Time Code, period = 1mS) -> task_button statechart
     Antirrebote del teclado 1x4 -> EV_KEYn_PRESSED a task_ui

    task_sensor.c (task_sensor.h, task_sensor_attribute.h)
     Non-Blocking Code (Update by Time Code, period = 1mS) -> ADC (LM35 + LDR)
     Promedio de 10 muestras cada 10 mS -> EV_INIT_DONE / EV_SENSE_TICK a task_system

      task_sensor_interface.c (task_sensor_interface.h)
       Non-Blocking Code

    task_system.c (task_system.h, task_system_attribute.h)
     Non-Blocking Code (Update by Time Code, period = 1mS) -> task_system statechart
     INIT / NORMAL / HEATING / SET_UP / ALARMA, EEPROM, EV_MODE_CHANGED

      task_system_interface.c (task_system_interface.h)
       Non-Blocking Code (cola de eventos + getters)

    task_ui.c (task_ui.h, task_ui_attribute.h)
     Non-Blocking Code (Update by Time Code, period = 1mS) -> task_ui statechart

      task_ui_interface.c (task_ui_interface.h)
       Non-Blocking Code (cola de eventos)

    task_display.c (task_display.h, task_display_attribute.h)
     Non-Blocking Code (Update by Time Code, period = 1mS) -> task_display statechart
     Escribe 1 caracter por mS en el LCD (ST_IDLE / ST_WRITE_CHAR)

      task_display_interface.c (task_display_interface.h)
       Non-Blocking Code (cola de eventos)

    task_signaling.c (task_signaling.h, task_signaling_attribute.h)
     Non-Blocking Code (Update by Time Code, period = 1mS) -> signaling statechart
     LED RGB, rele y buzzer segun el modo del sistema

      task_signaling_interface.c (task_signaling_interface.h)
       Non-Blocking Code (cola de eventos)

    task_actuator.c (task_actuator.h, task_actuator_attribute.h)
     Non-Blocking Code (Update by Time Code, period = 1mS) -> actuator statechart
     LED_R, LED_G, LED_B, RELAY, BUZZER, LD2 (heartbeat): ON / OFF / BLINK

      task_actuator_interface.c (task_actuator_interface.h)
       Non-Blocking Code

    task_bluetooth.c (task_bluetooth.h, task_bluetooth_attribute.h)
     Non-Blocking Code (Update by Time Code, period = 1mS) -> bluetooth statechart
     Telemetria cada 1 S, comandos SET_T=xx.x y MODE=SETUP, ACK / NACK, alertas

      task_bluetooth_interface.c (task_bluetooth_interface.h)
       Non-Blocking Code (cola de eventos)

  lcd.c (lcd.h)
   Driver LCD 16x2 HD44780 + PCF8574 (I2C1)

  eeprom.c (eeprom.h)
   Driver EEPROM 24Cxx (I2C1): T_set y T_max

  ble_uart.c (ble_uart.h)
   Driver USART1 no bloqueante (RX/TX por interrupcion, buffers circulares)

  logger.h (logger.c)
   Utilities for Retarget "printf" to Console

  dwt.h
   Utilities for Mesure "clock cycle" and "execution time" of code
  
  systick.c (systick.h) 
   Utilities for delay "microseconds"

  Special connection requirements:
   Ver REVISION.md (tabla de conexiones).

Build procedures:
Visit the Getting started with STM32: STM32 step-by-step at 
"https://wiki.st.com/stm32mcu/wiki/STM32StepByStep:Getting_started_with_STM32_:_STM32_step_by_step"
to get started building STM32 Projects.
